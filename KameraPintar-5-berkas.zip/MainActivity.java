package com.alibima.kamerapintar;

import static com.alibima.kamerapintar.Config.*;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.CamcorderProfile;
import android.media.ExifInterface;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import android.window.OnBackInvokedDispatcher;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// ===== MainActivity =====
/**
 * Layar utama. Setiap kali aplikasi dibuka (atau dibuka ulang) berlaku logika "sakelar" yang
 * sama seperti gestur pada skrip aslinya:
 * sesi aktif -> hentikan; menu terbuka -> tutup; belum kenalan -> pengenalan; selain itu -> menu.
 */
public class MainActivity extends Activity {

    private static final int REQ_IZIN = 77;

    final Handler handler = new Handler(Looper.getMainLooper());
    Prefs prefs;
    Terjemahan terj;
    Suara suara;
    Getar getar;
    MediaStorage media;
    SesiKamera sesi;
    MenuController menu;

    private Runnable lanjutSetelahIzin;
    private View root;

    private final Runnable batasLayar = new Runnable() {
        @Override
        public void run() {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        terj = new Terjemahan(prefs);
        suara = new Suara(this, prefs, terj);
        getar = new Getar(this);
        media = new MediaStorage(this);
        sesi = new SesiKamera(this);
        menu = new MenuController(this);

        buatTampilan();
        suara.setViewPengumuman(root);
        suara.siapkanMesin();

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::tanganiKembali);
        }

        denganIzin(new Runnable() {
            @Override
            public void run() {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        toggle();
                    }
                }, 600);
            }
        });
    }

    private void buatTampilan() {
        LinearLayout kotak = new LinearLayout(this);
        kotak.setOrientation(LinearLayout.VERTICAL);
        kotak.setGravity(Gravity.CENTER);
        int pad = Math.round(24 * getResources().getDisplayMetrics().density);
        kotak.setPadding(pad, pad, pad, pad);

        TextView judul = new TextView(this);
        judul.setText("Kamera Pintar");
        judul.setTextSize(28);
        judul.setGravity(Gravity.CENTER);
        judul.setPadding(0, 0, 0, pad);

        Button tombol = new Button(this);
        tombol.setText("Buka Menu");
        tombol.setTextSize(20);
        tombol.setContentDescription("Buka menu Kamera Pintar");
        tombol.setOnClickListener(v -> toggle());

        kotak.addView(judul);
        kotak.addView(tombol);
        setContentView(kotak);
        root = kotak;

        // Android 15+ menggambar di belakang bilah sistem; beri jarak aman.
        kotak.setOnApplyWindowInsetsListener((v, insets) -> {
            int kiri = 0, atas = 0, kanan = 0, bawah = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                kiri = i.left;
                atas = i.top;
                kanan = i.right;
                bawah = i.bottom;
            }
            v.setPadding(pad + kiri, pad + atas, pad + kanan, pad + bawah);
            return insets;
        });
    }

    // ---------- sakelar (setara gestur pada skrip asli) ----------

    void toggle() {
        if (sesi.aktif) {
            if (sesi.merekamVideo) {
                sesi.berhentiRekamVideo(false);
            } else {
                sesi.hentikan();
                getar.nonaktif();
                suara.ucapkan("Panduan kamera nonaktif.");
            }
        } else if (menu.sedangMenampilkanMenu) {
            menu.tutupMenuDenganPesan("Menu dibatalkan.");
            getar.nonaktif();
        } else if (!prefs.sudahKenalan()) {
            menu.tampilkanPengenalanPertamaKali();
        } else {
            menu.tampilkanMenuJenis();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        toggle();
    }

    // ---------- tombol Kembali & tombol volume ----------

    private void tanganiKembali() {
        if (sesi.aktif) {
            toggle();
        } else {
            finish();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        tanganiKembali();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Selama sesi berjalan, tombol volume = hentikan (cadangan bila goncangan tak terdeteksi).
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                && sesi.aktif) {
            if (event.getRepeatCount() == 0) toggle();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // ---------- layar tetap menyala ----------

    void jagaLayarNyala(boolean nyala) {
        handler.removeCallbacks(batasLayar);
        if (nyala) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            handler.postDelayed(batasLayar, Config.BATAS_LAYAR_NYALA_MS);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    // ---------- izin ----------

    void denganIzin(Runnable lanjut) {
        List<String> perlu = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            perlu.add(Manifest.permission.CAMERA);
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            perlu.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            perlu.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (perlu.isEmpty()) {
            lanjut.run();
            return;
        }
        lanjutSetelahIzin = lanjut;
        requestPermissions(perlu.toArray(new String[0]), REQ_IZIN);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_IZIN) {
            Runnable l = lanjutSetelahIzin;
            lanjutSetelahIzin = null;
            if (l != null) l.run();
        }
    }

    // ---------- siklus hidup ----------

    @Override
    protected void onStop() {
        super.onStop();
        try {
            if (sesi.aktif) {
                if (sesi.merekamVideo) {
                    sesi.berhentiRekamVideo(false);
                } else {
                    sesi.hentikan();
                }
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        try {
            sesi.hentikan();
        } catch (Exception ignored) {
        }
        handler.removeCallbacksAndMessages(null);
        suara.shutdown();
        super.onDestroy();
    }
}

// ===== Config =====
/** Semua konstanta/ambang yang sebelumnya ada di bagian atas main.lua. */
final class Config {
    private Config() {}

    static final String FOLDER = "Kamera Pintar";
    static final String SUBFOLDER_FOTO = "Foto";
    static final String SUBFOLDER_VIDEO = "Video";

    static final String MODE_GAMBAR = "gambar";
    static final String MODE_VIDEO = "video";
    static final String KAMERA_BELAKANG = "belakang";
    static final String KAMERA_DEPAN = "depan";

    // Ambang panduan wajah
    static final double TOLERANSI_OFFSET_WAJAH = 0.10;
    static final double TOLERANSI_UKURAN_WAJAH_MAKSIMUM = 0.5;
    static final double TOLERANSI_UKURAN_WAJAH_MINIMUM = 0.12;

    // Pencahayaan (skala 0-255)
    static final double TOLERANSI_CAHAYA_MINIMUM = 35;
    static final double TOLERANSI_CAHAYA_MAKSIMUM = 245;

    // Waktu (ms)
    static final long LAMA_STABIL_DIPERLUKAN_MS = 1600;
    static final long BATAS_WAKTU_SESI_MS = 45000;
    static final long BATAS_WAKTU_TANPA_WAJAH_MS = 3000;
    static final long MAKS_USIA_DATA_WAJAH_MS = 1200;
    static final long INTERVAL_PANDUAN_MS = 900;
    static final long INTERVAL_HITUNG_CAHAYA_MS = 800;
    static final long BATAS_WAKTU_ESKALASI_TANPA_WAJAH_MS = 8000;
    static final long BATAS_LAYAR_NYALA_MS = 600000;
    static final long JEDA_MINIMUM_SETELAH_UCAPAN_MS = 1200;
    static final long JEDA_SEBELUM_UCAPAN_MENU_MS = 700;

    // Goncangan untuk berhenti merekam
    static final double AMBANG_GONCANGAN_VIDEO = 10;

    // Sakelar arah (ubah jika arah panduan terbalik di ponsel Anda)
    static final boolean BALIK_ARAH_WAJAH_KAMERA_DEPAN = false;
    static final boolean BALIK_ARAH_HORIZONTAL = true;
    static final boolean BALIK_ARAH_VERTIKAL = false;
}

// ===== Prefs =====
/** Pembungkus SharedPreferences (nama berkas sama seperti skrip aslinya). */
final class Prefs {
    static final String NAMA = "PanduanKameraSuaraPengaturan";
    static final String NAMA_BAHASA_APLIKASI = "KameraPintarBahasaAplikasi";
    private static final String KUNCI_SUDAH_KENALAN = "sudahTampilPengenalanV1";

    private final Context ctx;

    Prefs(Context c) {
        ctx = c.getApplicationContext();
    }

    private SharedPreferences utama() {
        return ctx.getSharedPreferences(NAMA, Context.MODE_PRIVATE);
    }

    private SharedPreferences bahasa() {
        return ctx.getSharedPreferences(NAMA_BAHASA_APLIKASI, Context.MODE_PRIVATE);
    }

    // ---- mesin suara ----
    String getEngine() {
        try {
            return utama().getString("ttsEnginePackage", null);
        } catch (Exception e) {
            return null;
        }
    }

    void setEngine(String paket) {
        try {
            utama().edit().putString("ttsEnginePackage", paket).apply();
        } catch (Exception ignored) {
        }
    }

    // ---- bahasa ----
    String getBahasaAplikasi() {
        String b = "id";
        try {
            b = bahasa().getString("language", "id");
        } catch (Exception ignored) {
        }
        return "en".equals(b) ? "en" : "id";
    }

    void setBahasaAplikasi(String b) {
        try {
            bahasa().edit().putString("language", "en".equals(b) ? "en" : "id").apply();
        } catch (Exception ignored) {
        }
    }

    String getBahasaSuara() {
        String b = getBahasaAplikasi();
        try {
            b = utama().getString("ttsLanguage", b);
        } catch (Exception ignored) {
        }
        return "en".equals(b) ? "en" : "id";
    }

    void setBahasaSuara(String b) {
        try {
            utama().edit().putString("ttsLanguage", "en".equals(b) ? "en" : "id").apply();
        } catch (Exception ignored) {
        }
    }

    // ---- nada & kecepatan ----
    float getNada() {
        try {
            return utama().getFloat("ttsPitch", 1.0f);
        } catch (Exception e) {
            return 1.0f;
        }
    }

    float getKecepatan() {
        try {
            return utama().getFloat("ttsSpeechRate", 1.0f);
        } catch (Exception e) {
            return 1.0f;
        }
    }

    void setNadaKecepatan(float nada, float kecepatan) {
        try {
            utama().edit().putFloat("ttsPitch", nada).putFloat("ttsSpeechRate", kecepatan).apply();
        } catch (Exception ignored) {
        }
    }

    // ---- resolusi foto ----
    void simpanResolusiFoto(String facing, Integer lebar, Integer tinggi) {
        try {
            SharedPreferences.Editor e = utama().edit();
            if (lebar == null || tinggi == null) {
                e.remove("fotoLebar_" + facing);
                e.remove("fotoTinggi_" + facing);
            } else {
                e.putInt("fotoLebar_" + facing, lebar);
                e.putInt("fotoTinggi_" + facing, tinggi);
            }
            e.apply();
        } catch (Exception ignored) {
        }
    }

    /** @return {lebar, tinggi} atau null bila memakai Otomatis. */
    int[] getResolusiFoto(String facing) {
        try {
            int l = utama().getInt("fotoLebar_" + facing, -1);
            int t = utama().getInt("fotoTinggi_" + facing, -1);
            if (l > 0 && t > 0) return new int[] {l, t};
        } catch (Exception ignored) {
        }
        return null;
    }

    // ---- kualitas video ----
    void simpanKualitasVideo(String facing, Integer kualitas) {
        try {
            SharedPreferences.Editor e = utama().edit();
            if (kualitas == null) {
                e.remove("videoKualitas_" + facing);
            } else {
                e.putInt("videoKualitas_" + facing, kualitas);
            }
            e.apply();
        } catch (Exception ignored) {
        }
    }

    /** @return konstanta CamcorderProfile.QUALITY_* atau null bila Otomatis. */
    Integer getKualitasVideo(String facing) {
        try {
            int n = utama().getInt("videoKualitas_" + facing, -1);
            if (n >= 0) return n;
        } catch (Exception ignored) {
        }
        return null;
    }

    // ---- pengenalan pertama kali ----
    boolean sudahKenalan() {
        try {
            return utama().getBoolean(KUNCI_SUDAH_KENALAN, false);
        } catch (Exception e) {
            return true;
        }
    }

    void tandaiKenalan() {
        try {
            utama().edit().putBoolean(KUNCI_SUDAH_KENALAN, true).apply();
        } catch (Exception ignored) {
        }
    }
}

// ===== Terjemahan =====
/** Terjemahan Indonesia -> Inggris untuk tampilan (L) dan ucapan (tts). */
final class Terjemahan {
    private static final Map<String, String> UI_EN = new HashMap<>();
    private static final Map<String, String> TTS_EN = new HashMap<>();
    private static final Pattern POLA_ARAH = Pattern.compile(
            "^Wajah terlalu ke (kanan|kiri|bawah|atas), (\\d+) persen\\. Geser kamera ke (kanan|kiri|atas|bawah)\\.$");

    static {
        String[][] ui = {
            {"Pengaturan", "Settings"},
            {"Mesin Suara / Vocalizer", "Voice Engine / Vocalizer"},
            {"Pilih mesin suara", "Select voice engine"},
            {"Pengaturan nada bicara", "Speech pitch settings"},
            {"Pengaturan kecepatan bicara", "Speech rate settings"},
            {"Nada suara", "Speech pitch"},
            {"Kecepatan bicara", "Speech rate"},
            {"Pilih Resolusi", "Select Resolution"},
            {"Video", "Video"},
            {"Foto", "Photo"},
            {"Uji suara", "Test voice"},
            {"Pilih Bahasa", "Select Language"},
            {"Pilih bahasa", "Select language"},
            {"Bahasa Indonesia", "Indonesian"},
            {"Bahasa Inggris", "English"},
            {"Resolusi Foto", "Photo Resolution"},
            {"Resolusi Video", "Video Resolution"},
            {"Izin Jangan Ganggu Saat Rekam", "Do Not Disturb Permission During Recording"},
            {"Ambil Gambar", "Take Photo"},
            {"Rekam Video", "Record Video"},
            {"Keluar", "Exit"},
            {"Kembali", "Back"},
            {"Simpan", "Save"},
            {"Selesai", "Done"},
            {"Bagikan", "Share"},
            {"Hapus", "Delete"},
            {"Ganti Nama", "Rename"},
            {"Media Tersimpan", "Saved Media"},
            {"Lihat Foto", "View Photo"},
            {"Putar Video", "Play Video"},
            {"Kembali ke menu berbagi", "Back to sharing menu"},
            {"Pilih Jenis Pengambilan", "Choose Capture Type"},
            {"Kamera Belakang", "Rear Camera"},
            {"Kamera Depan", "Front Camera"},
            {"Atur Resolusi Kamera Mana?", "Which Camera Resolution to Set?"},
            {"Otomatis (disarankan)", "Automatic (recommended)"},
            {"Tertinggi", "Highest"},
            {"Sedang", "Medium"},
            {"Rendah", "Low"},
            {"Sangat Tinggi", "Very High"},
            {"Tinggi", "High"},
        };
        for (String[] p : ui) UI_EN.put(p[0], p[1]);

        String[][] tts = {
            {"Objek ditemukan.", "Object found."},
            {"Ada beberapa wajah terdeteksi. Memandu ke wajah paling dominan.", "Multiple faces detected. Guiding to the most prominent face."},
            {"Wajah terlalu ke kanan", "The face is too far right"},
            {"Wajah terlalu ke kiri", "The face is too far left"},
            {"Wajah terlalu ke bawah", "The face is too low"},
            {"Wajah terlalu ke atas", "The face is too high"},
            {"Geser kamera ke kanan.", "Move the camera right."},
            {"Geser kamera ke kiri.", "Move the camera left."},
            {"Geser kamera ke atas.", "Move the camera up."},
            {"Geser kamera ke bawah.", "Move the camera down."},
            {"Wajah terlalu dekat dan bisa terpotong. Jauhkan kamera sedikit.", "The face is too close and may be cropped. Move the camera slightly farther away."},
            {"Wajah terlalu jauh. Dekatkan kamera sedikit.", "The face is too far away. Move the camera slightly closer."},
            {"Wajah terlalu gelap. Arahkan kamera ke tempat yang lebih terang.", "The face is too dark. Point the camera toward a brighter place."},
            {"Pencahayaan terlalu silau. Arahkan kamera menjauhi sumber cahaya.", "The lighting is too bright. Point the camera away from the light source."},
            {"Pas. Kamera diam.", "Perfect. Hold the camera still."},
            {"Wajah belum terdeteksi. Arahkan kamera perlahan ke wajah.", "Face not detected. Slowly point the camera toward the face."},
            {"Wajah belum terdeteksi. Periksa lensa dan arahkan kamera perlahan ke wajah.", "Face not detected. Check the lens and slowly point the camera toward the face."},
            {"Deteksi wajah tidak tersedia pada kamera ini. Gunakan kamera lain.", "Face detection is not available on this camera. Use another camera."},
            {"Gagal menyiapkan kamera.", "Failed to prepare the camera."},
            {"Gagal membuka kamera. Periksa izin kamera di pengaturan aplikasi, atau mungkin kamera sedang dipakai aplikasi lain.", "Failed to open the camera. Check camera permission in app settings, or the camera may be in use by another app."},
            {"Gagal mengambil foto, mencoba lagi.", "Failed to take the photo. Trying again."},
            {"Wajah tidak lagi terdeteksi. Pengambilan dibatalkan.", "The face is no longer detected. Capture cancelled."},
            {"Posisi berubah, pemotretan dibatalkan. Mencoba lagi.", "The position changed. Photo capture cancelled. Trying again."},
            {"Wajah tidak lagi terdeteksi. Rekaman dibatalkan.", "The face is no longer detected. Recording cancelled."},
            {"Posisi berubah, rekaman dibatalkan. Mencoba lagi.", "The position changed. Recording cancelled. Trying again."},
            {"Gagal memulai perekaman video. Periksa izin kamera dan penyimpanan.", "Failed to start video recording. Check camera and storage permissions."},
            {"Tidak berhasil mendapatkan posisi kamera yang stabil. Asisten kamera berhenti, silakan coba lagi.", "Could not obtain a stable camera position. The camera assistant stopped. Please try again."},
            {"Panduan kamera nonaktif.", "Camera guidance is inactive."},
            {"Selesai.", "Done."},
            {"Berkas sudah dihapus.", "The file has been deleted."},
            {"Gagal menghapus berkas. Coba hapus lewat aplikasi Galeri.", "Failed to delete the file. Try deleting it through the Gallery app."},
            {"Video dijeda.", "Video paused."},
            {"Video diputar.", "Video playing."},
            {"Foto siap dilihat. Tekan Bagikan untuk membagikan, atau Kembali ke menu berbagi.", "The photo is ready to view. Press Share to share it, or Back to the sharing menu."},
            {"Foto tidak dapat ditampilkan. Anda masih dapat mencoba membagikannya.", "The photo cannot be displayed. You can still try to share it."},
            {"Pilih aplikasi untuk membagikan media.", "Choose an app to share the media."},
        };
        for (String[] p : tts) TTS_EN.put(p[0], p[1]);
    }

    private final Prefs prefs;

    Terjemahan(Prefs prefs) {
        this.prefs = prefs;
    }

    /** Terjemahkan teks tampilan (judul/tombol) bila bahasa aplikasi Inggris. */
    String l(String teks) {
        if ("en".equals(prefs.getBahasaAplikasi())) {
            String t = UI_EN.get(teks);
            return t != null ? t : teks;
        }
        return teks;
    }

    /** Terjemahkan kalimat yang diucapkan bila bahasa aplikasi Inggris. */
    String tts(String teks) {
        if (teks == null) return "";
        if (!"en".equals(prefs.getBahasaAplikasi())) return teks;
        String hasil = TTS_EN.get(teks);
        if (hasil != null) return hasil;
        Matcher m = POLA_ARAH.matcher(teks);
        if (m.matches()) {
            return "The face is too " + posisi(m.group(1)) + ", " + m.group(2)
                    + " percent. Move the camera " + arah(m.group(3)) + ".";
        }
        return teks;
    }

    private static String posisi(String s) {
        switch (s) {
            case "kanan": return "far right";
            case "kiri": return "far left";
            case "bawah": return "low";
            default: return "high";
        }
    }

    private static String arah(String s) {
        switch (s) {
            case "kanan": return "right";
            case "kiri": return "left";
            case "atas": return "up";
            default: return "down";
        }
    }
}

// ===== Suara =====
/** Mesin suara (TextToSpeech): pilih engine, bahasa, nada, kecepatan, dan ucapan. */
final class Suara {

    interface Hasil {
        void selesai(boolean ok);
    }

    private final Context ctx;
    private final Prefs prefs;
    private final Terjemahan terj;

    private TextToSpeech tts;
    private boolean siap;
    private String engineDipilih;
    private int generasi;
    private View viewPengumuman;

    Suara(Context ctx, Prefs prefs, Terjemahan terj) {
        this.ctx = ctx;
        this.prefs = prefs;
        this.terj = terj;
    }

    /** View cadangan: bila TTS belum siap, kalimat diumumkan lewat TalkBack. */
    void setViewPengumuman(View v) {
        viewPengumuman = v;
    }

    String getEngineDipilih() {
        return engineDipilih;
    }

    void siapkanMesin() {
        final String tersimpan = prefs.getEngine();
        buatMesin(tersimpan, ok -> {
            if (!ok && tersimpan != null) {
                prefs.setEngine("");
                buatMesin(null, null);
            }
        });
    }

    void buatMesin(final String paket, final Hasil cb) {
        tutup();
        final int gen = ++generasi;
        TextToSpeech.OnInitListener listener = status -> {
            if (gen != generasi) return; // callback mesin lama diabaikan
            boolean ok = (status == TextToSpeech.SUCCESS);
            if (ok) {
                siap = true;
                engineDipilih = paket;
                terapkanPengaturan();
            }
            if (cb != null) cb.selesai(ok);
        };
        try {
            if (paket != null && !paket.isEmpty()) {
                tts = new TextToSpeech(ctx, listener, paket);
            } else {
                tts = new TextToSpeech(ctx, listener);
            }
        } catch (Exception e) {
            tts = null;
            if (cb != null) cb.selesai(false);
        }
    }

    void tutup() {
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        tts = null;
        siap = false;
    }

    void shutdown() {
        generasi++;
        tutup();
    }

    boolean terapkanBahasa() {
        if (tts == null || !siap) return false;
        int kode = -2;
        try {
            if ("en".equals(prefs.getBahasaSuara())) {
                kode = tts.setLanguage(Locale.US);
            } else {
                kode = tts.setLanguage(Locale.forLanguageTag("id-ID"));
            }
        } catch (Exception ignored) {
        }
        return kode == 0 || kode == 1 || kode == 2;
    }

    void terapkanPengaturan() {
        try {
            if (tts != null && siap) {
                terapkanBahasa();
                tts.setPitch(prefs.getNada());
                tts.setSpeechRate(prefs.getKecepatan());
            }
        } catch (Exception ignored) {
        }
    }

    void ucapkan(String teks) {
        String isi = terj.tts(teks);
        boolean berhasil = false;
        try {
            if (tts != null && siap) {
                int h = tts.speak(isi, TextToSpeech.QUEUE_FLUSH, null,
                        "kamera_pintar_" + (System.currentTimeMillis() / 1000));
                berhasil = (h == TextToSpeech.SUCCESS);
            }
        } catch (Exception ignored) {
        }
        if (!berhasil && viewPengumuman != null) {
            try {
                viewPengumuman.announceForAccessibility(isi);
            } catch (Exception ignored) {
            }
        }
    }

    /** Perkiraan lama sebuah kalimat diucapkan (ms), dipakai untuk menjeda langkah berikutnya. */
    long durasi(String teks) {
        long d = (teks == null ? 30 : teks.length()) * 70L;
        if (d < Config.JEDA_MINIMUM_SETELAH_UCAPAN_MS) d = Config.JEDA_MINIMUM_SETELAH_UCAPAN_MS;
        return d;
    }

    /** @return daftar {namaPaket, label} semua mesin suara yang terpasang. */
    List<String[]> daftarEngine() {
        List<String[]> hasil = new ArrayList<>();
        TextToSpeech sementara = null;
        try {
            sementara = new TextToSpeech(ctx, status -> { });
            List<TextToSpeech.EngineInfo> engines = sementara.getEngines();
            for (TextToSpeech.EngineInfo info : engines) {
                hasil.add(new String[] {String.valueOf(info.name), String.valueOf(info.label)});
            }
        } catch (Exception ignored) {
        } finally {
            try {
                if (sementara != null) sementara.shutdown();
            } catch (Exception ignored) {
            }
        }
        return hasil;
    }
}

// ===== Getar =====
/** Pola getar penanda status. */
final class Getar {
    private final Context ctx;

    Getar(Context c) {
        ctx = c.getApplicationContext();
    }

    private Vibrator ambil() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager vm = (VibratorManager) ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                return vm != null ? vm.getDefaultVibrator() : null;
            }
            return (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("deprecation")
    private void satu(long ms) {
        Vibrator v = ambil();
        if (v == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(ms);
            }
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private void pola(long[] p) {
        Vibrator v = ambil();
        if (v == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(p, -1));
            } else {
                v.vibrate(p, -1);
            }
        } catch (Exception ignored) {
        }
    }

    /** Panduan kamera mulai aktif. */
    void aktif() {
        satu(120);
    }

    /** Panduan dibatalkan / dihentikan / gagal. */
    void nonaktif() {
        pola(new long[] {0, 100, 100, 100});
    }

    /** Foto/video berhasil. */
    void sukses() {
        pola(new long[] {0, 70, 60, 70, 60, 70});
    }

    void mulaiRekam() {
        satu(250);
    }

    void hitungMundur() {
        satu(50);
    }
}

// ===== MediaStorage =====
/** Simpan/ganti nama/hapus foto & video di DCIM/Kamera Pintar/{Foto,Video}. */
final class MediaStorage {
    private final Context ctx;

    MediaStorage(Context c) {
        ctx = c;
    }

    @SuppressWarnings("deprecation")
    private void siapkanLokasi(ContentValues values, String subFolder, String namaBerkas) {
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DCIM + "/" + Config.FOLDER + "/" + subFolder);
            return;
        }
        try {
            File publik = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File tujuan = new File(new File(publik, Config.FOLDER), subFolder);
            if (!tujuan.exists()) tujuan.mkdirs();
            values.put(MediaStore.MediaColumns.DATA, new File(tujuan, namaBerkas).getAbsolutePath());
        } catch (Exception ignored) {
        }
    }

    /** @return Uri foto yang tersimpan, atau null bila gagal. */
    Uri simpanFoto(byte[] data) {
        try {
            ContentResolver r = ctx.getContentResolver();
            ContentValues v = new ContentValues();
            String nama = "Foto_" + System.currentTimeMillis() + ".jpg";
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, nama);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            siapkanLokasi(v, Config.SUBFOLDER_FOTO, nama);
            Uri uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return null;
            try (OutputStream os = r.openOutputStream(uri)) {
                if (os == null) {
                    r.delete(uri, null, null);
                    return null;
                }
                os.write(data);
                os.flush();
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    /** Buat entri video kosong di galeri untuk ditulis oleh MediaRecorder. */
    Uri buatUriVideoBaru() {
        try {
            ContentValues v = new ContentValues();
            String nama = "Video_" + System.currentTimeMillis() + ".mp4";
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, nama);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
            siapkanLokasi(v, Config.SUBFOLDER_VIDEO, nama);
            return ctx.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
        } catch (Exception e) {
            return null;
        }
    }

    String ambilNama(Uri uri, String cadangan) {
        String hasil = cadangan;
        try (Cursor c = ctx.getContentResolver().query(uri,
                new String[] {MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
                if (i >= 0) hasil = c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return hasil;
    }

    boolean gantiNama(Uri uri, String namaBaru) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, namaBaru);
            int n = ctx.getContentResolver().update(uri, v, null, null);
            return n >= 1;
        } catch (Exception e) {
            return false;
        }
    }

    boolean hapus(Uri uri) {
        try {
            ctx.getContentResolver().delete(uri, null, null);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---- pembantu nama berkas ----

    static String namaDasarTanpaEkstensi(String namaLama, String ekstensi) {
        String nama = namaLama == null ? "" : namaLama;
        if (nama.endsWith(ekstensi)) nama = nama.substring(0, nama.length() - ekstensi.length());
        if (nama.isEmpty()) {
            nama = (".jpg".equals(ekstensi) ? "Foto_" : "Video_") + System.currentTimeMillis();
        }
        return nama;
    }

    static String bersihkanNamaBerkas(String nama) {
        String n = nama == null ? "" : nama;
        n = n.replaceAll("[\\\\/:*?\"<>|]", "_");
        n = n.replaceAll("^\\s+", "").replaceAll("\\s+$", "");
        return n;
    }

    static String buangEkstensiMedia(String nama) {
        String n = nama.replaceAll("\\.[Jj][Pp][Ee]?[Gg]$", "");
        n = n.replaceAll("\\.[Mm][Pp]4$", "");
        return n;
    }
}

// ===== SesiKamera =====
/**
 * Sesi asisten kamera: membuka kamera (API Camera1, sama seperti skrip aslinya), memandu
 * lewat suara/getar, lalu otomatis memotret atau merekam begitu posisi bagus dan stabil.
 */
final class SesiKamera {

    static final class ResolusiTarget {
        Integer lebar;
        Integer tinggi;
        Integer kualitas;
    }

    static final class OpsiResolusi {
        String label;
        String tipe; // "auto", "kualitas", atau "ukuran"
        int nilai;
        int lebar;
        int tinggi;
    }

    private static final class UkuranFoto {
        final int lebar;
        final int tinggi;
        final long piksel;

        UkuranFoto(int l, int t) {
            lebar = l;
            tinggi = t;
            piksel = (long) l * t;
        }
    }

    private static final class InfoFoto {
        UkuranFoto tertinggi;
        UkuranFoto sedang;
        UkuranFoto rendah;
    }

    private final MainActivity host;

    // ---- status sesi ----
    boolean aktif;
    boolean merekamVideo;
    private boolean sedangMemotret;
    private boolean bersiapMemotret;
    private boolean bersiapRekam;

    private Camera kamera;
    private SurfaceTexture dummy;
    private String modePengambilan = MODE_GAMBAR;
    private String kameraDipilih = KAMERA_BELAKANG;
    private int idKamera;
    private int orientasiSensor;
    private Integer kualitasVideo;

    private boolean dukungDeteksiWajah;
    private boolean wajahTerdeteksi;
    private boolean dukungPreviewCahaya;
    private Double rataRataCahaya;
    private long waktuHitungCahayaTerakhir;
    private double offsetKiriKanan;
    private double offsetAtasBawah;
    private Double rasioUkuranWajah;
    private long waktuTerakhirWajah;
    private int jumlahWajah;
    private boolean objekPernahDitemukan;
    private boolean multiWajahDiumumkan;

    private long waktuMulaiSesi;
    private Long waktuMulaiKondisiBagus;
    private String pesanTerakhir;
    private long waktuPanduanTerakhir;

    private MediaRecorder recorder;
    private ParcelFileDescriptor pfd;
    private Uri uriVideo;
    private Double magnitudeSebelumnya;

    private SensorManager sensorManager;
    private SensorEventListener sensorListener;

    private Integer volAksesibilitas;
    private Integer volMedia;
    private Integer filterDnd;
    private Runnable runnableBisukan;
    private boolean sudahDiberitahuDnd;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            jalankanLoop();
        }
    };

    SesiKamera(MainActivity host) {
        this.host = host;
    }

    private void ucapkan(String s) {
        host.suara.ucapkan(s);
    }

    // ============================================================
    // Layar, rotasi, sensor
    // ============================================================

    private int rotasiLayarDerajat() {
        try {
            Display d;
            if (Build.VERSION.SDK_INT >= 30) {
                d = host.getDisplay();
            } else {
                d = host.getWindowManager().getDefaultDisplay();
            }
            if (d == null) return 0;
            switch (d.getRotation()) {
                case Surface.ROTATION_90: return 90;
                case Surface.ROTATION_180: return 180;
                case Surface.ROTATION_270: return 270;
                default: return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }

    static int hitungRotasiPengambilan(int orientasiSensor, int rotasiLayar, boolean depan) {
        if (depan) return (orientasiSensor + rotasiLayar) % 360;
        return (orientasiSensor - rotasiLayar + 360) % 360;
    }

    private void mulaiSensor() {
        try {
            SensorManager sm = (SensorManager) host.getSystemService(Context.SENSOR_SERVICE);
            Sensor akselerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (akselerometer == null) return;
            SensorEventListener l = new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent event) {
                    if (event == null || event.values == null || event.values.length < 3) return;
                    double x = event.values[0];
                    double y = event.values[1];
                    double z = event.values[2];
                    if (merekamVideo) {
                        double magnitude = Math.sqrt(x * x + y * y + z * z);
                        if (magnitudeSebelumnya != null) {
                            double selisih = Math.abs(magnitude - magnitudeSebelumnya);
                            if (selisih > AMBANG_GONCANGAN_VIDEO && merekamVideo) {
                                berhentiRekamVideo(false);
                            }
                        }
                        magnitudeSebelumnya = magnitude;
                    }
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {
                }
            };
            sm.registerListener(l, akselerometer, SensorManager.SENSOR_DELAY_GAME);
            sensorManager = sm;
            sensorListener = l;
        } catch (Exception ignored) {
        }
    }

    private void hentikanSensor() {
        try {
            if (sensorManager != null && sensorListener != null) {
                sensorManager.unregisterListener(sensorListener);
            }
        } catch (Exception ignored) {
        }
        sensorManager = null;
        sensorListener = null;
    }

    // ============================================================
    // Suara senyap saat merekam (Jangan Ganggu)
    // ============================================================

    boolean apakahDndDiizinkan() {
        try {
            NotificationManager nm = (NotificationManager) host.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.isNotificationPolicyAccessGranted();
        } catch (Exception e) {
            return false;
        }
    }

    private void bisukanSemuaSuara() {
        try {
            AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    volAksesibilitas = am.getStreamVolume(AudioManager.STREAM_ACCESSIBILITY);
                    am.setStreamVolume(AudioManager.STREAM_ACCESSIBILITY, 0, 0);
                } catch (Exception ignored) {
                }
            }
            try {
                volMedia = am.getStreamVolume(AudioManager.STREAM_MUSIC);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
            } catch (Exception ignored) {
            }
        } catch (Exception ignored) {
        }
        try {
            if (apakahDndDiizinkan()) {
                NotificationManager nm = (NotificationManager) host.getSystemService(Context.NOTIFICATION_SERVICE);
                filterDnd = nm.getCurrentInterruptionFilter();
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            }
        } catch (Exception ignored) {
        }
    }

    private void pulihkanSuara() {
        try {
            if (runnableBisukan != null) host.handler.removeCallbacks(runnableBisukan);
        } catch (Exception ignored) {
        }
        runnableBisukan = null;
        try {
            AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            if (volAksesibilitas != null && Build.VERSION.SDK_INT >= 26) {
                try {
                    am.setStreamVolume(AudioManager.STREAM_ACCESSIBILITY, volAksesibilitas, 0);
                } catch (Exception ignored) {
                }
            }
            if (volMedia != null) {
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, volMedia, 0);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        try {
            if (filterDnd != null) {
                NotificationManager nm = (NotificationManager) host.getSystemService(Context.NOTIFICATION_SERVICE);
                nm.setInterruptionFilter(filterDnd);
            }
        } catch (Exception ignored) {
        }
        volAksesibilitas = null;
        volMedia = null;
        filterDnd = null;
    }

    // ============================================================
    // Pencarian kamera & ukuran
    // ============================================================

    /** @return {idKamera, orientasiSensor} atau null bila tidak ada. */
    int[] cariKamera(String facingDiinginkan) {
        int dicari = KAMERA_DEPAN.equals(facingDiinginkan)
                ? Camera.CameraInfo.CAMERA_FACING_FRONT
                : Camera.CameraInfo.CAMERA_FACING_BACK;
        try {
            int jumlah = Camera.getNumberOfCameras();
            for (int i = 0; i < jumlah; i++) {
                Camera.CameraInfo info = new Camera.CameraInfo();
                Camera.getCameraInfo(i, info);
                if (info.facing == dicari) return new int[] {i, info.orientation};
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static Camera.Size pilihUkuranTerdekat(List<Camera.Size> daftar, int tLebar, int tTinggi) {
        Camera.Size terbaik = null;
        long selisihTerbaik = -1;
        if (daftar == null) return null;
        for (Camera.Size u : daftar) {
            long selisih = Math.abs((long) u.width * u.height - (long) tLebar * tTinggi);
            if (selisihTerbaik < 0 || selisih < selisihTerbaik) {
                selisihTerbaik = selisih;
                terbaik = u;
            }
        }
        return terbaik;
    }

    private static Camera.Size pilihPratinjauSesuaiRasio(List<Camera.Size> daftar, double rasioTarget) {
        Camera.Size terbaik = null;
        long selisihTerbaik = -1;
        if (daftar == null) return null;
        for (Camera.Size u : daftar) {
            double rasioIni = (double) u.width / u.height;
            if (Math.abs(rasioIni - rasioTarget) <= 0.03) {
                long selisihArea = Math.abs((long) u.width * u.height - 640L * 480L);
                if (selisihTerbaik < 0 || selisihArea < selisihTerbaik) {
                    selisihTerbaik = selisihArea;
                    terbaik = u;
                }
            }
        }
        if (terbaik != null) return terbaik;
        return pilihUkuranTerdekat(daftar, 640, 480);
    }

    private int[] perkiraanUkuranVideo(int id, Integer kualitasDiinginkan) {
        Integer kualitas = null;
        try {
            if (kualitasDiinginkan != null && CamcorderProfile.hasProfile(id, kualitasDiinginkan)) {
                kualitas = kualitasDiinginkan;
            }
        } catch (Exception ignored) {
        }
        if (kualitas == null) kualitas = kualitasBawaan(id);
        int lebar = 1280;
        int tinggi = 720;
        if (kualitas != null) {
            try {
                CamcorderProfile p = CamcorderProfile.get(id, kualitas);
                if (p != null) {
                    lebar = p.videoFrameWidth;
                    tinggi = p.videoFrameHeight;
                }
            } catch (Exception ignored) {
            }
        }
        return new int[] {lebar, tinggi};
    }

    /** 720p bila ada, kalau tidak QUALITY_HIGH; null bila tidak ada keduanya. */
    private static Integer kualitasBawaan(int id) {
        try {
            if (CamcorderProfile.hasProfile(id, CamcorderProfile.QUALITY_720P)) {
                return CamcorderProfile.QUALITY_720P;
            } else if (CamcorderProfile.hasProfile(id, CamcorderProfile.QUALITY_HIGH)) {
                return CamcorderProfile.QUALITY_HIGH;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private InfoFoto ambilInfoFoto(int id) {
        Camera cam = null;
        try {
            cam = Camera.open(id);
            List<Camera.Size> daftar = cam.getParameters().getSupportedPictureSizes();
            List<UkuranFoto> semua = new ArrayList<>();
            UkuranFoto terbesar = null;
            UkuranFoto terkecil = null;
            for (Camera.Size u : daftar) {
                UkuranFoto item = new UkuranFoto(u.width, u.height);
                semua.add(item);
                if (terbesar == null || item.piksel > terbesar.piksel) terbesar = item;
                if (terkecil == null || item.piksel < terkecil.piksel) terkecil = item;
            }
            if (terbesar == null) return null;
            double targetSedang = terbesar.piksel / 2.0;
            UkuranFoto sedang = null;
            double selisihTerbaik = -1;
            for (UkuranFoto item : semua) {
                double selisih = Math.abs(item.piksel - targetSedang);
                if (selisihTerbaik < 0 || selisih < selisihTerbaik) {
                    selisihTerbaik = selisih;
                    sedang = item;
                }
            }
            InfoFoto hasil = new InfoFoto();
            hasil.tertinggi = terbesar;
            hasil.sedang = sedang;
            hasil.rendah = terkecil;
            return hasil;
        } catch (Exception e) {
            return null;
        } finally {
            try {
                if (cam != null) cam.release();
            } catch (Exception ignored) {
            }
        }
    }

    /** Daftar pilihan resolusi untuk menu Pengaturan (foto atau video). */
    List<OpsiResolusi> susunOpsiResolusi(String modePengaturan, Integer id) {
        List<OpsiResolusi> data = new ArrayList<>();
        OpsiResolusi auto = new OpsiResolusi();
        auto.label = "Otomatis (disarankan)";
        auto.tipe = "auto";
        data.add(auto);
        if (id == null) return data;

        if (MODE_VIDEO.equals(modePengaturan)) {
            int[] kualitas = {CamcorderProfile.QUALITY_2160P, CamcorderProfile.QUALITY_1080P,
                    CamcorderProfile.QUALITY_720P, CamcorderProfile.QUALITY_480P};
            String[] nama = {"Sangat Tinggi", "Tinggi", "Sedang", "Rendah"};
            for (int i = 0; i < kualitas.length; i++) {
                try {
                    if (CamcorderProfile.hasProfile(id, kualitas[i])) {
                        String labelUkuran = "";
                        try {
                            CamcorderProfile p = CamcorderProfile.get(id, kualitas[i]);
                            if (p != null) {
                                labelUkuran = " (" + p.videoFrameWidth + " x " + p.videoFrameHeight + ")";
                            }
                        } catch (Exception ignored) {
                        }
                        OpsiResolusi o = new OpsiResolusi();
                        o.label = host.terj.l(nama[i]) + labelUkuran;
                        o.tipe = "kualitas";
                        o.nilai = kualitas[i];
                        data.add(o);
                    }
                } catch (Exception ignored) {
                }
            }
        } else {
            InfoFoto info = ambilInfoFoto(id);
            if (info != null) {
                UkuranFoto[] urutan = {info.tertinggi, info.sedang, info.rendah};
                String[] nama = {"Tertinggi", "Sedang", "Rendah"};
                for (int i = 0; i < urutan.length; i++) {
                    if (urutan[i] != null) {
                        OpsiResolusi o = new OpsiResolusi();
                        o.label = String.format(Locale.ROOT, "%s (%d x %d)",
                                host.terj.l(nama[i]), urutan[i].lebar, urutan[i].tinggi);
                        o.tipe = "ukuran";
                        o.lebar = urutan[i].lebar;
                        o.tinggi = urutan[i].tinggi;
                        data.add(o);
                    }
                }
            }
        }
        return data;
    }

    // ============================================================
    // Berhenti
    // ============================================================

    void hentikan() {
        aktif = false;
        host.handler.removeCallbacksAndMessages(null);
        hentikanSensor();
        host.jagaLayarNyala(false);
        pulihkanSuara();
        if (kamera != null) {
            try {
                kamera.stopFaceDetection();
            } catch (Exception ignored) {
            }
            try {
                kamera.setPreviewCallback(null);
            } catch (Exception ignored) {
            }
            try {
                kamera.stopPreview();
            } catch (Exception ignored) {
            }
            try {
                kamera.release();
            } catch (Exception ignored) {
            }
        }
        kamera = null;
        if (dummy != null) {
            try {
                dummy.release();
            } catch (Exception ignored) {
            }
        }
        dummy = null;
        wajahTerdeteksi = false;
        rasioUkuranWajah = null;
        dukungPreviewCahaya = false;
        rataRataCahaya = null;
        waktuMulaiKondisiBagus = null;
        sedangMemotret = false;
        bersiapMemotret = false;
        merekamVideo = false;
        bersiapRekam = false;
        recorder = null;
        pfd = null;
        uriVideo = null;
        magnitudeSebelumnya = null;
    }

    // ============================================================
    // Panduan wajah
    // ============================================================

    private double[] hitungOffsetWajahKeBingkai(double cx, double cy, boolean depan) {
        double x = cx / 1000.0;
        double y = cy / 1000.0;
        int rotasi = hitungRotasiPengambilan(orientasiSensor, rotasiLayarDerajat(), depan);
        double nx;
        double ny;
        if (rotasi == 90) {
            nx = y;
            ny = -x;
        } else if (rotasi == 180) {
            nx = -x;
            ny = -y;
        } else if (rotasi == 270) {
            nx = -y;
            ny = x;
        } else {
            nx = x;
            ny = y;
        }
        if (depan && BALIK_ARAH_WAJAH_KAMERA_DEPAN) nx = -nx;
        return new double[] {nx / 2.0, ny / 2.0};
    }

    private static final class Kandidat {
        final double kelebihan;
        final String pesan;

        Kandidat(double k, String p) {
            kelebihan = k;
            pesan = p;
        }
    }

    private String buatPesanPanduanUtama(boolean menungguWajahPertama) {
        long sekarang = System.currentTimeMillis();
        if (!dukungDeteksiWajah) {
            return "Deteksi wajah tidak tersedia pada kamera ini. Gunakan kamera lain.";
        }
        if (!wajahTerdeteksi || menungguWajahPertama) {
            if (sekarang - waktuMulaiSesi >= BATAS_WAKTU_ESKALASI_TANPA_WAJAH_MS) {
                return "Wajah belum terdeteksi. Periksa lensa dan arahkan kamera perlahan ke wajah.";
            }
            return "Wajah belum terdeteksi. Arahkan kamera perlahan ke wajah.";
        }

        List<Kandidat> kandidat = new ArrayList<>();

        double dx = offsetKiriKanan;
        long persenX = Math.round(Math.abs(dx) * 100);
        double kelebihanX = (Math.abs(dx) - TOLERANSI_OFFSET_WAJAH) / TOLERANSI_OFFSET_WAJAH;
        String arahX;
        if (dx > 0) {
            arahX = BALIK_ARAH_HORIZONTAL ? "kiri" : "kanan";
        } else {
            arahX = BALIK_ARAH_HORIZONTAL ? "kanan" : "kiri";
        }
        if (kelebihanX > 0) {
            kandidat.add(new Kandidat(kelebihanX,
                    (dx > 0 ? "Wajah terlalu ke kanan" : "Wajah terlalu ke kiri")
                            + ", " + persenX + " persen. Geser kamera ke " + arahX + "."));
        }

        double dy = offsetAtasBawah;
        long persenY = Math.round(Math.abs(dy) * 100);
        double kelebihanY = (Math.abs(dy) - TOLERANSI_OFFSET_WAJAH) / TOLERANSI_OFFSET_WAJAH;
        String arahY;
        if (dy > 0) {
            arahY = BALIK_ARAH_VERTIKAL ? "bawah" : "atas";
        } else {
            arahY = BALIK_ARAH_VERTIKAL ? "atas" : "bawah";
        }
        if (kelebihanY > 0) {
            kandidat.add(new Kandidat(kelebihanY,
                    (dy > 0 ? "Wajah terlalu ke bawah" : "Wajah terlalu ke atas")
                            + ", " + persenY + " persen. Geser kamera ke " + arahY + "."));
        }

        if (rasioUkuranWajah != null) {
            double rasio = rasioUkuranWajah;
            if (rasio > TOLERANSI_UKURAN_WAJAH_MAKSIMUM) {
                double k = (rasio - TOLERANSI_UKURAN_WAJAH_MAKSIMUM) / TOLERANSI_UKURAN_WAJAH_MAKSIMUM;
                if (k > 0) {
                    kandidat.add(new Kandidat(k,
                            "Wajah terlalu dekat dan bisa terpotong. Jauhkan kamera sedikit."));
                }
            } else if (rasio < TOLERANSI_UKURAN_WAJAH_MINIMUM) {
                double k = (TOLERANSI_UKURAN_WAJAH_MINIMUM - rasio) / TOLERANSI_UKURAN_WAJAH_MINIMUM;
                if (k > 0) {
                    kandidat.add(new Kandidat(k, "Wajah terlalu jauh. Dekatkan kamera sedikit."));
                }
            }
        }

        if (dukungPreviewCahaya && rataRataCahaya != null) {
            double c = rataRataCahaya;
            if (c < TOLERANSI_CAHAYA_MINIMUM) {
                double k = (TOLERANSI_CAHAYA_MINIMUM - c) / TOLERANSI_CAHAYA_MINIMUM;
                if (k > 0) {
                    kandidat.add(new Kandidat(k,
                            "Wajah terlalu gelap. Arahkan kamera ke tempat yang lebih terang."));
                }
            } else if (c > TOLERANSI_CAHAYA_MAKSIMUM) {
                double k = (c - TOLERANSI_CAHAYA_MAKSIMUM) / (255 - TOLERANSI_CAHAYA_MAKSIMUM);
                if (k > 0) {
                    kandidat.add(new Kandidat(k,
                            "Pencahayaan terlalu silau. Arahkan kamera menjauhi sumber cahaya."));
                }
            }
        }

        Kandidat terbaik = null;
        for (Kandidat k : kandidat) {
            if (terbaik == null || k.kelebihan > terbaik.kelebihan) terbaik = k;
        }
        if (terbaik != null) return terbaik.pesan;
        return "Pas. Kamera diam.";
    }

    /** @return {lurusOK, tengahOK, jarakOK, cahayaOK, menungguWajahPertama} */
    private boolean[] evaluasiKondisi() {
        boolean lurusOK = true;
        if (!dukungDeteksiWajah || !wajahTerdeteksi) {
            return new boolean[] {lurusOK, false, false, false, true};
        }
        long sekarang = System.currentTimeMillis();
        if (sekarang - waktuTerakhirWajah > MAKS_USIA_DATA_WAJAH_MS) {
            wajahTerdeteksi = false;
            return new boolean[] {lurusOK, false, false, false, true};
        }
        boolean tengahOK = Math.abs(offsetKiriKanan) <= TOLERANSI_OFFSET_WAJAH
                && Math.abs(offsetAtasBawah) <= TOLERANSI_OFFSET_WAJAH;
        boolean jarakOK = false;
        if (rasioUkuranWajah != null) {
            jarakOK = rasioUkuranWajah <= TOLERANSI_UKURAN_WAJAH_MAKSIMUM
                    && rasioUkuranWajah >= TOLERANSI_UKURAN_WAJAH_MINIMUM;
        }
        boolean cahayaOK = true;
        if (dukungPreviewCahaya && rataRataCahaya != null) {
            cahayaOK = rataRataCahaya >= TOLERANSI_CAHAYA_MINIMUM
                    && rataRataCahaya <= TOLERANSI_CAHAYA_MAKSIMUM;
        }
        return new boolean[] {lurusOK, tengahOK, jarakOK, cahayaOK, false};
    }

    // ============================================================
    // Foto
    // ============================================================

    @SuppressWarnings("deprecation")
    private static int derajatDariExif(byte[] data) {
        try (InputStream in = new ByteArrayInputStream(data)) {
            ExifInterface exif = new ExifInterface(in);
            int o = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch (o) {
                case ExifInterface.ORIENTATION_ROTATE_90: return 90;
                case ExifInterface.ORIENTATION_ROTATE_180: return 180;
                case ExifInterface.ORIENTATION_ROTATE_270: return 270;
                default: return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Putar piksel foto agar tegak di semua penampil (tidak bergantung pada catatan EXIF).
     * Bila foto sudah tegak, data asli dikembalikan apa adanya (tanpa kompres ulang).
     */
    private static byte[] luruskanFoto(byte[] data, int rotasiDiminta) {
        try {
            int exifDerajat = derajatDariExif(data);
            BitmapFactory.Options batas = new BitmapFactory.Options();
            batas.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, batas);
            int lebar = batas.outWidth;
            int tinggi = batas.outHeight;
            if (lebar <= 0 || tinggi <= 0) return data;

            int putar = 0;
            if (exifDerajat != 0) {
                putar = exifDerajat; // kamera sudah mencatat arah putaran
            } else if (rotasiDiminta == 180) {
                putar = 180;
            } else if ((rotasiDiminta == 90 || rotasiDiminta == 270) && lebar > tinggi) {
                putar = rotasiDiminta; // piksel masih mendatar, belum diputar kamera
            }
            if (putar == 0) return data;

            for (int sample = 1; sample <= 2; sample++) {
                try {
                    BitmapFactory.Options opsi = new BitmapFactory.Options();
                    opsi.inSampleSize = sample;
                    Bitmap asli = BitmapFactory.decodeByteArray(data, 0, data.length, opsi);
                    if (asli == null) return data;
                    Matrix m = new Matrix();
                    m.postRotate(putar);
                    Bitmap hasil = Bitmap.createBitmap(asli, 0, 0, asli.getWidth(), asli.getHeight(), m, true);
                    if (hasil != asli) asli.recycle();
                    ByteArrayOutputStream out = new ByteArrayOutputStream(data.length);
                    hasil.compress(Bitmap.CompressFormat.JPEG, 97, out);
                    hasil.recycle();
                    return out.toByteArray();
                } catch (OutOfMemoryError e) {
                    // coba lagi dengan resolusi setengah
                }
            }
        } catch (Exception ignored) {
        }
        return data;
    }

    private void ambilFotoSekarang(final boolean wajahUtuhSaatJepret) {
        if (kamera == null || sedangMemotret) return;
        sedangMemotret = true;
        final boolean depan = KAMERA_DEPAN.equals(kameraDipilih);
        final int rotasiFoto = hitungRotasiPengambilan(orientasiSensor, rotasiLayarDerajat(), depan);
        try {
            Camera.Parameters p = kamera.getParameters();
            p.setRotation(rotasiFoto);
            kamera.setParameters(p);
        } catch (Exception ignored) {
        }
        Camera.PictureCallback jpeg = new Camera.PictureCallback() {
            @Override
            public void onPictureTaken(final byte[] data, Camera cam) {
                if (data == null || data.length == 0) {
                    sedangMemotret = false;
                    host.getar.nonaktif();
                    ucapkan("Foto belum berhasil, data tidak utuh. Stabilkan kamera, mencoba lagi.");
                    waktuMulaiKondisiBagus = null;
                    jalankanLoop();
                    return;
                }
                // Memutar foto bisa memakan waktu sedikit, jadi dikerjakan di luar thread utama.
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final byte[] lurus = luruskanFoto(data, rotasiFoto);
                        host.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                selesaikanFoto(lurus, wajahUtuhSaatJepret);
                            }
                        });
                    }
                }).start();
            }
        };
        try {
            kamera.takePicture(null, null, jpeg);
        } catch (Exception e) {
            sedangMemotret = false;
            ucapkan("Gagal mengambil foto, mencoba lagi.");
        }
    }

    private void selesaikanFoto(byte[] data, boolean wajahUtuhSaatJepret) {
        final Uri uri = host.media.simpanFoto(data);
        host.getar.sukses();
        if (uri != null) {
            String pesan = wajahUtuhSaatJepret
                    ? "Foto berhasil diambil, wajah utuh di tengah bingkai, dan disimpan."
                    : "Foto berhasil diambil dan disimpan.";
            ucapkan(pesan);
            hentikan();
            host.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    host.menu.tampilkanMenuSetelahAmbil(uri, "image/jpeg", "Lihat Foto");
                }
            }, host.suara.durasi(pesan));
        } else {
            String pesan = "Foto sudah diambil secara utuh, tapi gagal menyimpan ke galeri.";
            ucapkan(pesan);
            host.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    hentikan();
                }
            }, host.suara.durasi(pesan));
        }
    }

    private void benarBenarAmbilFoto() {
        bersiapMemotret = false;
        if (!aktif || kamera == null || sedangMemotret) return;
        boolean[] ev = evaluasiKondisi();
        if (!dukungDeteksiWajah || !wajahTerdeteksi) {
            ucapkan("Wajah tidak lagi terdeteksi. Pengambilan dibatalkan.");
            host.getar.nonaktif();
            waktuMulaiKondisiBagus = null;
            jalankanLoop();
            return;
        }
        if (!(ev[0] && ev[1] && ev[2] && ev[3])) {
            ucapkan("Posisi berubah, pemotretan dibatalkan. Mencoba lagi.");
            host.getar.nonaktif();
            waktuMulaiKondisiBagus = null;
            jalankanLoop();
            return;
        }
        boolean wajahUtuh = dukungDeteksiWajah && wajahTerdeteksi && ev[1] && ev[2];
        ambilFotoSekarang(wajahUtuh);
    }

    private void hitungMundurFoto(final int n) {
        if (!aktif || !bersiapMemotret) return;
        if (n > 0) {
            host.getar.hitungMundur();
            String kata = n == 3 ? "Tiga" : n == 2 ? "Dua" : n == 1 ? "Satu" : String.valueOf(n);
            ucapkan(kata);
            host.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    hitungMundurFoto(n - 1);
                }
            }, 1000);
        } else {
            benarBenarAmbilFoto();
        }
    }

    private void bersiapAmbilFoto() {
        if (kamera == null || sedangMemotret || bersiapMemotret) return;
        bersiapMemotret = true;
        String pesan = "Pas, kamera diam. Bersiap, foto diambil.";
        ucapkan(pesan);
        host.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hitungMundurFoto(3);
            }
        }, host.suara.durasi(pesan));
    }

    // ============================================================
    // Video
    // ============================================================

    void berhentiRekamVideo(boolean alasanOtomatis) {
        if (!merekamVideo) return;
        MediaRecorder rek = recorder;
        ParcelFileDescriptor p = pfd;
        final Uri uri = uriVideo;
        merekamVideo = false;
        boolean berhentiOk = true;
        try {
            if (rek != null) rek.stop();
        } catch (Exception e) {
            berhentiOk = false;
        }
        try {
            if (rek != null) rek.reset();
        } catch (Exception ignored) {
        }
        try {
            if (rek != null) rek.release();
        } catch (Exception ignored) {
        }
        try {
            if (kamera != null) kamera.lock();
        } catch (Exception ignored) {
        }
        try {
            if (p != null) p.close();
        } catch (Exception ignored) {
        }
        pulihkanSuara();
        if (berhentiOk) {
            host.getar.sukses();
            String pesan = "Video berhasil direkam dan disimpan.";
            ucapkan(pesan);
            hentikan();
            host.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    host.menu.tampilkanMenuSetelahAmbil(uri, "video/mp4", "Putar Video");
                }
            }, host.suara.durasi(pesan));
        } else {
            if (uri != null) host.media.hapus(uri);
            host.getar.nonaktif();
            String pesan = "Gagal menyimpan video. Coba rekam lebih lama sebelum berhenti.";
            ucapkan(pesan);
            host.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    hentikan();
                }
            }, host.suara.durasi(pesan));
        }
    }

    private MediaRecorder buatMediaRecorder() {
        if (Build.VERSION.SDK_INT >= 31) return new MediaRecorder(host);
        return new MediaRecorder();
    }

    private boolean cobaMulaiRekam(boolean sertakanAudio, Integer kualitas, int rotasiVideo) {
        Uri uri = host.media.buatUriVideoBaru();
        if (uri == null) return false;
        ContentResolver resolver = host.getContentResolver();
        ParcelFileDescriptor berkas;
        try {
            berkas = resolver.openFileDescriptor(uri, "rw");
        } catch (Exception e) {
            berkas = null;
        }
        if (berkas == null) {
            host.media.hapus(uri);
            return false;
        }
        MediaRecorder rek = buatMediaRecorder();
        try {
            try {
                kamera.unlock();
            } catch (Exception ignored) {
            }
            rek.setCamera(kamera);
            if (sertakanAudio) rek.setAudioSource(MediaRecorder.AudioSource.MIC);
            rek.setVideoSource(MediaRecorder.VideoSource.CAMERA);
            if (kualitas != null) {
                CamcorderProfile profil = CamcorderProfile.get(idKamera, kualitas);
                if (sertakanAudio) {
                    rek.setProfile(profil);
                } else {
                    // Tanpa audio: terapkan bagian video dari profil secara manual
                    rek.setOutputFormat(profil.fileFormat);
                    rek.setVideoFrameRate(profil.videoFrameRate);
                    rek.setVideoSize(profil.videoFrameWidth, profil.videoFrameHeight);
                    rek.setVideoEncodingBitRate(profil.videoBitRate);
                    rek.setVideoEncoder(profil.videoCodec);
                }
            } else {
                rek.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                rek.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
                if (sertakanAudio) rek.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                rek.setVideoSize(1280, 720);
                rek.setVideoFrameRate(30);
                rek.setVideoEncodingBitRate(6000000);
            }
            rek.setOutputFile(berkas.getFileDescriptor());
            rek.setOrientationHint(rotasiVideo);
            rek.prepare();
            rek.start();
        } catch (Exception e) {
            try {
                rek.reset();
            } catch (Exception ignored) {
            }
            try {
                rek.release();
            } catch (Exception ignored) {
            }
            try {
                berkas.close();
            } catch (Exception ignored) {
            }
            host.media.hapus(uri);
            try {
                if (kamera != null) kamera.lock();
            } catch (Exception ignored) {
            }
            return false;
        }
        recorder = rek;
        pfd = berkas;
        uriVideo = uri;
        return true;
    }

    private void benarBenarMulaiRekamVideo() {
        bersiapRekam = false;
        if (!aktif || kamera == null || merekamVideo) return;
        boolean[] ev = evaluasiKondisi();
        if (!dukungDeteksiWajah || !wajahTerdeteksi) {
            ucapkan("Wajah tidak lagi terdeteksi. Rekaman dibatalkan.");
            host.getar.nonaktif();
            waktuMulaiKondisiBagus = null;
            jalankanLoop();
            return;
        }
        if (!(ev[0] && ev[1] && ev[2] && ev[3])) {
            ucapkan("Posisi berubah, rekaman dibatalkan. Mencoba lagi.");
            host.getar.nonaktif();
            waktuMulaiKondisiBagus = null;
            jalankanLoop();
            return;
        }
        try {
            kamera.stopFaceDetection();
        } catch (Exception ignored) {
        }
        try {
            kamera.setPreviewCallback(null);
        } catch (Exception ignored) {
        }

        boolean depan = KAMERA_DEPAN.equals(kameraDipilih);
        int rotasiVideo = hitungRotasiPengambilan(orientasiSensor, rotasiLayarDerajat(), depan);

        Integer kualitas = null;
        try {
            if (kualitasVideo != null && CamcorderProfile.hasProfile(idKamera, kualitasVideo)) {
                kualitas = kualitasVideo;
            }
        } catch (Exception ignored) {
        }
        if (kualitas == null) kualitas = kualitasBawaan(idKamera);

        boolean denganSuara = cobaMulaiRekam(true, kualitas, rotasiVideo);
        if (!denganSuara) {
            boolean tanpaSuara = cobaMulaiRekam(false, kualitas, rotasiVideo);
            if (!tanpaSuara) {
                ucapkan("Gagal memulai perekaman video. Periksa izin kamera dan penyimpanan.");
                hentikan();
                return;
            }
            merekamVideo = true;
            magnitudeSebelumnya = null;
            host.getar.mulaiRekam();
            String pesan = "Mikrofon tidak tersedia, video direkam tanpa suara.";
            ucapkan(pesan);
            runnableBisukan = new Runnable() {
                @Override
                public void run() {
                    runnableBisukan = null;
                    if (merekamVideo) bisukanSemuaSuara();
                }
            };
            host.handler.postDelayed(runnableBisukan, host.suara.durasi(pesan));
        } else {
            merekamVideo = true;
            magnitudeSebelumnya = null;
            host.getar.mulaiRekam();
            bisukanSemuaSuara();
        }
    }

    private void mulaiRekamVideo() {
        if (kamera == null || merekamVideo || bersiapRekam) return;
        bersiapRekam = true;
        String pesan = "Objek sudah pas, kamera siap. Perekaman dimulai. Goncangkan ponsel kapan saja untuk berhenti merekam.";
        ucapkan(pesan);
        host.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                benarBenarMulaiRekamVideo();
            }
        }, host.suara.durasi(pesan));
    }

    // ============================================================
    // Loop panduan
    // ============================================================

    void jalankanLoop() {
        if (!aktif) return;
        long sekarang = System.currentTimeMillis();
        if (sekarang - waktuMulaiSesi >= BATAS_WAKTU_SESI_MS) {
            ucapkan("Tidak berhasil mendapatkan posisi kamera yang stabil. Asisten kamera berhenti, silakan coba lagi.");
            hentikan();
            return;
        }
        if (sekarang - waktuTerakhirWajah > BATAS_WAKTU_TANPA_WAJAH_MS) {
            wajahTerdeteksi = false;
        }
        boolean[] ev = evaluasiKondisi();
        boolean menungguWajahPertama = ev[4];
        boolean bagus = ev[0] && ev[1] && ev[2] && ev[3];

        if (wajahTerdeteksi && !objekPernahDitemukan) {
            objekPernahDitemukan = true;
            ucapkan("Objek ditemukan.");
            pesanTerakhir = null;
            host.handler.postDelayed(loop, INTERVAL_PANDUAN_MS);
            return;
        }
        if (jumlahWajah > 1 && !multiWajahDiumumkan) {
            multiWajahDiumumkan = true;
            ucapkan("Ada beberapa wajah terdeteksi. Memandu ke wajah paling dominan.");
            pesanTerakhir = null;
            host.handler.postDelayed(loop, INTERVAL_PANDUAN_MS);
            return;
        }
        if (!wajahTerdeteksi && objekPernahDitemukan && menungguWajahPertama) {
            objekPernahDitemukan = false;
            multiWajahDiumumkan = false;
        }

        String pesan = buatPesanPanduanUtama(menungguWajahPertama);
        boolean sudahLama = (sekarang - waktuPanduanTerakhir) >= 4000;
        if (!pesan.equals(pesanTerakhir) || sudahLama) {
            ucapkan(pesan);
            pesanTerakhir = pesan;
            waktuPanduanTerakhir = sekarang;
        }

        if (bagus) {
            if (waktuMulaiKondisiBagus == null) {
                waktuMulaiKondisiBagus = sekarang;
            } else if (sekarang - waktuMulaiKondisiBagus >= LAMA_STABIL_DIPERLUKAN_MS) {
                if (MODE_VIDEO.equals(modePengambilan)) {
                    mulaiRekamVideo();
                } else {
                    bersiapAmbilFoto();
                }
                return;
            }
        } else {
            waktuMulaiKondisiBagus = null;
        }
        host.handler.postDelayed(loop, INTERVAL_PANDUAN_MS);
    }

    // ============================================================
    // Mulai sesi
    // ============================================================

    private void benarMulai(String mode, String facing, ResolusiTarget target) {
        final boolean depan = KAMERA_DEPAN.equals(facing);
        int[] info = cariKamera(facing);
        if (info == null) {
            ucapkan("Tidak ditemukan kamera " + (depan ? "depan" : "belakang") + " di perangkat ini.");
            aktif = false;
            return;
        }
        final int id = info[0];
        orientasiSensor = info[1];

        if (MODE_VIDEO.equals(mode) && target != null && target.kualitas != null) {
            kualitasVideo = target.kualitas;
        } else {
            kualitasVideo = null;
        }

        final Camera cam;
        try {
            cam = Camera.open(id);
        } catch (Exception e) {
            ucapkan("Gagal membuka kamera. Periksa izin kamera di pengaturan aplikasi, atau mungkin kamera sedang dipakai aplikasi lain.");
            aktif = false;
            return;
        }
        if (cam == null) {
            ucapkan("Gagal membuka kamera. Periksa izin kamera di pengaturan aplikasi, atau mungkin kamera sedang dipakai aplikasi lain.");
            aktif = false;
            return;
        }
        kamera = cam;
        idKamera = id;
        modePengambilan = mode;
        kameraDipilih = facing;

        boolean siap = false;
        try {
            Camera.Parameters params = cam.getParameters();
            int targetLebarFoto = 1920;
            int targetTinggiFoto = 1080;
            if (target != null && target.lebar != null && target.tinggi != null) {
                targetLebarFoto = target.lebar;
                targetTinggiFoto = target.tinggi;
            }
            Camera.Size ukuranFoto = pilihUkuranTerdekat(params.getSupportedPictureSizes(),
                    targetLebarFoto, targetTinggiFoto);
            if (ukuranFoto != null) params.setPictureSize(ukuranFoto.width, ukuranFoto.height);

            double rasioTarget;
            if (MODE_VIDEO.equals(mode)) {
                int[] uv = perkiraanUkuranVideo(id, kualitasVideo);
                rasioTarget = (double) uv[0] / uv[1];
            } else if (ukuranFoto != null) {
                rasioTarget = (double) ukuranFoto.width / ukuranFoto.height;
            } else {
                rasioTarget = 4.0 / 3.0;
            }
            Camera.Size ukuranPreview = pilihPratinjauSesuaiRasio(params.getSupportedPreviewSizes(), rasioTarget);
            if (ukuranPreview != null) params.setPreviewSize(ukuranPreview.width, ukuranPreview.height);

            try {
                List<String> modeFokus = params.getSupportedFocusModes();
                if (modeFokus != null && modeFokus.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                }
            } catch (Exception ignored) {
            }

            int rotasiLayar = rotasiLayarDerajat();
            params.setRotation(hitungRotasiPengambilan(orientasiSensor, rotasiLayar, depan));
            cam.setParameters(params);

            int lebarPratinjau = 640;
            int tinggiPratinjau = 480;
            if (ukuranPreview != null) {
                lebarPratinjau = ukuranPreview.width;
                tinggiPratinjau = ukuranPreview.height;
            }
            SurfaceTexture tekstur = new SurfaceTexture(0);
            try {
                tekstur.detachFromGLContext();
            } catch (Exception ignored) {
            }
            tekstur.setDefaultBufferSize(lebarPratinjau, tinggiPratinjau);
            cam.setPreviewTexture(tekstur);
            dummy = tekstur;
            cam.setDisplayOrientation(rotasiLayar);
            cam.startPreview();

            // Deteksi wajah (tidak semua kamera mendukung)
            dukungDeteksiWajah = false;
            try {
                if (params.getMaxNumDetectedFaces() > 0) {
                    cam.setFaceDetectionListener(new Camera.FaceDetectionListener() {
                        @Override
                        public void onFaceDetection(Camera.Face[] faces, Camera c) {
                            Camera.Face terbaik = null;
                            int luasTerbesar = -1;
                            int jumlah = 0;
                            if (faces != null) {
                                for (Camera.Face f : faces) {
                                    if (f == null || f.rect == null) continue;
                                    jumlah++;
                                    int luas = Math.abs(f.rect.right - f.rect.left)
                                            * Math.abs(f.rect.bottom - f.rect.top);
                                    if (luas > luasTerbesar) {
                                        luasTerbesar = luas;
                                        terbaik = f;
                                    }
                                }
                            }
                            jumlahWajah = jumlah;
                            if (terbaik != null) {
                                Rect r = terbaik.rect;
                                double cx = (r.left + r.right) / 2.0;
                                double cy = (r.top + r.bottom) / 2.0;
                                double[] off = hitungOffsetWajahKeBingkai(cx, cy, depan);
                                offsetKiriKanan = off[0];
                                offsetAtasBawah = off[1];
                                int lebarWajah = Math.abs(r.right - r.left);
                                int tinggiWajah = Math.abs(r.bottom - r.top);
                                rasioUkuranWajah = Math.max(lebarWajah, tinggiWajah) / 2000.0;
                                wajahTerdeteksi = true;
                                waktuTerakhirWajah = System.currentTimeMillis();
                            } else {
                                wajahTerdeteksi = false;
                            }
                        }
                    });
                    cam.startFaceDetection();
                    dukungDeteksiWajah = true;
                }
            } catch (Exception ignored) {
            }

            // Kecerahan dari data pratinjau (asumsi NV21: byte awal = luma)
            dukungPreviewCahaya = false;
            try {
                final int batasLuma = lebarPratinjau * tinggiPratinjau;
                cam.setPreviewCallback(new Camera.PreviewCallback() {
                    @Override
                    public void onPreviewFrame(byte[] data, Camera c) {
                        long sekarang = System.currentTimeMillis();
                        if (sekarang - waktuHitungCahayaTerakhir < INTERVAL_HITUNG_CAHAYA_MS) return;
                        waktuHitungCahayaTerakhir = sekarang;
                        try {
                            if (data == null) return;
                            int batas = Math.min(batasLuma, data.length);
                            long total = 0;
                            int sampel = 0;
                            for (int i = 0; i < batas; i += 97) {
                                total += (data[i] & 0xFF);
                                sampel++;
                            }
                            if (sampel > 0) rataRataCahaya = (double) total / sampel;
                        } catch (Exception ignored) {
                        }
                    }
                });
                dukungPreviewCahaya = true;
            } catch (Exception ignored) {
            }
            siap = true;
        } catch (Exception e) {
            siap = false;
        }

        if (!siap) {
            try {
                cam.release();
            } catch (Exception ignored) {
            }
            kamera = null;
            ucapkan("Gagal menyiapkan kamera.");
            aktif = false;
            return;
        }

        mulaiSensor();
        host.jagaLayarNyala(true);
        aktif = true;
        waktuMulaiSesi = System.currentTimeMillis();
        waktuMulaiKondisiBagus = null;
        sedangMemotret = false;
        bersiapMemotret = false;
        objekPernahDitemukan = false;
        multiWajahDiumumkan = false;
        pesanTerakhir = null;
        waktuPanduanTerakhir = 0;
        jumlahWajah = 0;
        waktuTerakhirWajah = 0;
        offsetKiriKanan = 0;
        offsetAtasBawah = 0;
        host.getar.aktif();
        ucapkan("Panduan kamera aktif. Arahkan kamera " + (depan ? "depan" : "belakang")
                + " ke subjek, saya akan memandu dan "
                + (MODE_VIDEO.equals(mode) ? "mulai merekam" : "memotret") + " otomatis.");
        jalankanLoop();
    }

    void mulai(final String mode, final String facing, final ResolusiTarget target) {
        if (MODE_VIDEO.equals(mode) && !sudahDiberitahuDnd && !apakahDndDiizinkan()) {
            sudahDiberitahuDnd = true;
            String pesan = "Catatan: izin Akses Kebijakan Notifikasi belum diberikan, jadi panggilan dan notifikasi mungkin masih terdengar saat merekam video. Bisa diaktifkan nanti lewat Pengaturan aplikasi ini.";
            ucapkan(pesan);
            aktif = true;
            host.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!aktif) return;
                    benarMulai(mode, facing, target);
                }
            }, host.suara.durasi(pesan));
            return;
        }
        benarMulai(mode, facing, target);
    }
}

// ===== MenuController =====
/** Semua dialog/menu aplikasi (menu utama, pengaturan, media tersimpan, dll.). */
final class MenuController {

    private final MainActivity act;
    private AlertDialog dialogAktif;
    boolean sedangMenampilkanMenu;

    MenuController(MainActivity act) {
        this.act = act;
    }

    // ---------- pembantu ----------

    private String L(String teks) {
        return act.terj.l(teks);
    }

    private void ucap(String teks) {
        act.suara.ucapkan(teks);
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                act.getResources().getDisplayMetrics()));
    }

    private AlertDialog tampil(AlertDialog.Builder builder, final String pesanUcapan) {
        if (act.isFinishing() || act.isDestroyed()) return null;
        final AlertDialog dialog = builder.create();
        dialogAktif = dialog;
        dialog.show();
        if (pesanUcapan != null) {
            act.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (dialogAktif == dialog) ucap(pesanUcapan);
                }
            }, JEDA_SEBELUM_UCAPAN_MENU_MS);
        }
        return dialog;
    }

    private void tutupDialogAktif() {
        if (dialogAktif != null) {
            try {
                dialogAktif.dismiss();
            } catch (Exception ignored) {
            }
        }
        dialogAktif = null;
    }

    void tutupMenuDenganPesan(String pesan) {
        tutupDialogAktif();
        sedangMenampilkanMenu = false;
        if (pesan != null) ucap(pesan);
    }

    private TextView buatBaris(String teks, String deskripsi) {
        TextView t = new TextView(act);
        t.setText(teks);
        t.setContentDescription(deskripsi);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        t.setMinHeight(dp(56));
        t.setClickable(true);
        t.setFocusable(true);
        return t;
    }

    // ============================================================
    // Menu utama
    // ============================================================

    void tampilkanMenuJenis() {
        sedangMenampilkanMenu = true;
        String[] opsi = {L("Ambil Gambar"), L("Rekam Video"), L("Pengaturan")};
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L("Pilih Jenis Pengambilan"))
                .setItems(opsi, (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    if (which == 0) {
                        tampilkanMenuKamera(MODE_GAMBAR);
                    } else if (which == 1) {
                        tampilkanMenuKamera(MODE_VIDEO);
                    } else {
                        tampilkanMenuPengaturan();
                    }
                })
                .setNegativeButton(L("Keluar"), (d, w) -> keluar())
                .setOnCancelListener(d -> keluar());
        dialogAktif = tampil(b, "Pilih Ambil Gambar, Rekam Video, Pengaturan, atau Keluar.");
    }

    private void keluar() {
        tutupMenuDenganPesan("Keluar.");
        act.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                act.finish();
            }
        }, 900);
    }

    void tampilkanMenuKamera(final String modeDipilih) {
        sedangMenampilkanMenu = true;
        String[] opsi = {L("Kamera Belakang"), L("Kamera Depan")};
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle("Pilih Kamera")
                .setItems(opsi, (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    final String facing = (which == 0) ? KAMERA_BELAKANG : KAMERA_DEPAN;
                    SesiKamera.ResolusiTarget target = null;
                    if (MODE_GAMBAR.equals(modeDipilih)) {
                        int[] r = act.prefs.getResolusiFoto(facing);
                        if (r != null) {
                            target = new SesiKamera.ResolusiTarget();
                            target.lebar = r[0];
                            target.tinggi = r[1];
                        }
                    } else {
                        Integer k = act.prefs.getKualitasVideo(facing);
                        if (k != null) {
                            target = new SesiKamera.ResolusiTarget();
                            target.kualitas = k;
                        }
                    }
                    final SesiKamera.ResolusiTarget targetAkhir = target;
                    act.denganIzin(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                act.sesi.mulai(modeDipilih, facing, targetAkhir);
                            } catch (Exception e) {
                                ucap("Gagal menjalankan asisten kamera: " + e);
                                try {
                                    act.sesi.hentikan();
                                } catch (Exception ignored) {
                                }
                            }
                        }
                    });
                })
                .setNegativeButton("Kembali", (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    tampilkanMenuJenis();
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    tampilkanMenuJenis();
                });
        dialogAktif = tampil(b, "Pilih kamera belakang, atau kamera depan.");
    }

    // ============================================================
    // Pengaturan
    // ============================================================

    void tampilkanMenuPengaturan() {
        sedangMenampilkanMenu = true;
        String[] opsi = {L("Mesin Suara / Vocalizer"), L("Pilih Bahasa"), L("Resolusi Foto"),
                L("Resolusi Video"), L("Izin Jangan Ganggu Saat Rekam")};
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L("Pengaturan"))
                .setItems(opsi, (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    if (which == 0) {
                        tampilkanMenuMesinSuara();
                    } else if (which == 1) {
                        tampilkanPengaturanBahasaAplikasi();
                    } else if (which == 2) {
                        tampilkanMenuPengaturanKamera(MODE_GAMBAR);
                    } else if (which == 3) {
                        tampilkanMenuPengaturanKamera(MODE_VIDEO);
                    } else {
                        sedangMenampilkanMenu = false;
                        if (act.sesi.apakahDndDiizinkan()) {
                            ucap("Izin Jangan Ganggu sudah diberikan. Nada dering dan notifikasi akan otomatis disenyapkan saat merekam video.");
                        } else {
                            ucap("Membuka halaman izin Akses Kebijakan Notifikasi. Aktifkan untuk aplikasi ini, lalu kembali ke aplikasi.");
                            bukaPengaturanDnd();
                        }
                    }
                })
                .setNegativeButton("Kembali", (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    tampilkanMenuJenis();
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    tampilkanMenuJenis();
                });
        dialogAktif = tampil(b, "Pengaturan. Pilih resolusi foto, resolusi video, izin Jangan Ganggu saat rekam, atau tekan kembali untuk ke menu utama.");
    }

    private void bukaPengaturanDnd() {
        try {
            Intent i = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            act.startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private void tampilkanMenuPengaturanKamera(final String modePengaturan) {
        sedangMenampilkanMenu = true;
        String[] opsi = {L("Kamera Belakang"), L("Kamera Depan")};
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L("Atur Resolusi Kamera Mana?"))
                .setItems(opsi, (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    tampilkanMenuPengaturanResolusi(modePengaturan,
                            which == 0 ? KAMERA_BELAKANG : KAMERA_DEPAN);
                })
                .setNegativeButton("Kembali", (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    tampilkanMenuPengaturan();
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    tampilkanMenuPengaturan();
                });
        dialogAktif = tampil(b, "Pilih kamera belakang, atau kamera depan, yang ingin diatur resolusinya.");
    }

    private void tampilkanMenuPengaturanResolusi(final String modePengaturan, final String facing) {
        sedangMenampilkanMenu = true;
        int[] info = act.sesi.cariKamera(facing);
        Integer id = info == null ? null : Integer.valueOf(info[0]);
        final List<SesiKamera.OpsiResolusi> opsiData = act.sesi.susunOpsiResolusi(modePengaturan, id);
        String[] labelSaja = new String[opsiData.size()];
        for (int i = 0; i < labelSaja.length; i++) labelSaja[i] = L(opsiData.get(i).label);
        final boolean video = MODE_VIDEO.equals(modePengaturan);
        final String namaJenis = video ? "video" : "foto";
        final String namaKamera = KAMERA_DEPAN.equals(facing) ? "depan" : "belakang";
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L("Pilih Resolusi") + " " + L(video ? "Video" : "Foto"))
                .setItems(labelSaja, (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    if (which >= 0 && which < opsiData.size()) {
                        SesiKamera.OpsiResolusi dipilih = opsiData.get(which);
                        if (video) {
                            if ("kualitas".equals(dipilih.tipe)) {
                                act.prefs.simpanKualitasVideo(facing, dipilih.nilai);
                            } else {
                                act.prefs.simpanKualitasVideo(facing, null);
                            }
                        } else {
                            if ("ukuran".equals(dipilih.tipe)) {
                                act.prefs.simpanResolusiFoto(facing, dipilih.lebar, dipilih.tinggi);
                            } else {
                                act.prefs.simpanResolusiFoto(facing, null, null);
                            }
                        }
                        ucap("Resolusi " + namaJenis + " kamera " + namaKamera + " diatur ke "
                                + dipilih.label + ". Tersimpan permanen sampai diubah lagi.");
                    }
                    tampilkanMenuPengaturan();
                })
                .setNegativeButton("Kembali", (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    tampilkanMenuPengaturanKamera(modePengaturan);
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    tampilkanMenuPengaturanKamera(modePengaturan);
                });
        dialogAktif = tampil(b, "Pilih resolusi " + namaJenis + " untuk kamera " + namaKamera + ", atau otomatis.");
    }

    // ---------- mesin suara ----------

    void tampilkanMenuMesinSuara() {
        sedangMenampilkanMenu = true;
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        String[][] pilihan = {
            {L("Pilih mesin suara"), "Memilih mesin suara atau Vocalizer"},
            {L("Pengaturan nada bicara"), "Mengatur tinggi rendah nada bicara"},
            {L("Pengaturan kecepatan bicara"), "Mengatur kecepatan bicara"},
            {L("Uji suara"), "Mendengarkan contoh suara dari mesin yang dipilih"},
        };
        for (int i = 0; i < pilihan.length; i++) {
            final int indeks = i + 1;
            TextView baris = buatBaris(pilihan[i][0], pilihan[i][1]);
            baris.setOnClickListener(v -> {
                if (indeks == 1) {
                    tutupDialogAktif();
                    tampilkanDaftarMesinSuara();
                } else if (indeks == 2) {
                    tutupDialogAktif();
                    tampilkanPengaturanNada();
                } else if (indeks == 3) {
                    tutupDialogAktif();
                    tampilkanPengaturanKecepatan();
                } else {
                    act.suara.terapkanPengaturan();
                    if ("en".equals(act.prefs.getBahasaSuara())) {
                        ucap("This is an example of the voice engine you selected.");
                    } else {
                        ucap("Ini adalah contoh mesin suara yang Anda pilih.");
                    }
                }
            });
            box.addView(baris);
        }
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L("Mesin Suara / Vocalizer"))
                .setView(box)
                .setNegativeButton("Kembali", (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    tampilkanMenuPengaturan();
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    tampilkanMenuPengaturan();
                });
        dialogAktif = tampil(b, "Pilih mesin suara, pengaturan nada bicara, pengaturan kecepatan bicara, atau uji suara.");
    }

    private void tampilkanDaftarMesinSuara() {
        sedangMenampilkanMenu = true;
        final List<String> daftar = new ArrayList<>();
        final List<String> paket = new ArrayList<>();
        String namaDipilih = act.suara.getEngineDipilih();
        if (namaDipilih == null) namaDipilih = act.prefs.getEngine();
        for (String[] e : act.suara.daftarEngine()) {
            String label = e[1];
            if (e[0].equals(namaDipilih)) label = label + " (dipilih)";
            daftar.add(label);
            paket.add(e[0]);
        }
        if (daftar.isEmpty()) {
            daftar.add("Gunakan mesin suara bawaan Android");
            paket.add("");
        }
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle("Pilih Mesin Suara / Vocalizer")
                .setItems(daftar.toArray(new String[0]), (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    final String dipilih = paket.get(which);
                    final String label = daftar.get(which);
                    if (dipilih.isEmpty()) {
                        act.prefs.setEngine("");
                        act.suara.buatMesin(null, ok -> {
                            ucap(ok ? "Mesin suara bawaan Android dipilih."
                                    : "Mesin suara bawaan Android tidak dapat digunakan.");
                            tampilkanMenuMesinSuara();
                        });
                    } else {
                        act.suara.buatMesin(dipilih, ok -> {
                            if (ok) {
                                act.prefs.setEngine(dipilih);
                                ucap("Mesin suara " + label.replace(" (dipilih)", "") + " berhasil dipilih.");
                            } else {
                                ucap("Mesin suara yang dipilih tidak dapat digunakan.");
                            }
                            tampilkanMenuMesinSuara();
                        });
                    }
                })
                .setNegativeButton("Kembali", (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    tampilkanMenuMesinSuara();
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    tampilkanMenuMesinSuara();
                });
        dialogAktif = tampil(b, "Pilih mesin suara atau Vocalizer yang terpasang di ponsel.");
    }

    private static String persen(float nilai) {
        return Math.round(nilai * 100) + "%";
    }

    private void tampilkanPengaturanSeekBar(final boolean untukNada) {
        sedangMenampilkanMenu = true;
        float awal = untukNada ? act.prefs.getNada() : act.prefs.getKecepatan();
        final String judulLabel = untukNada ? "Nada suara" : "Kecepatan bicara";
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        final TextView label = new TextView(act);
        label.setText(L(judulLabel) + ": " + persen(awal));
        final SeekBar bar = new SeekBar(act);
        bar.setMax(150);
        bar.setProgress(Math.round((awal - 0.5f) * 100));
        box.addView(label);
        box.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                label.setText(L(judulLabel) + ": " + persen(0.5f + progress / 100f));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L(untukNada ? "Pengaturan nada bicara" : "Pengaturan kecepatan bicara"))
                .setView(box)
                .setPositiveButton(L("Simpan"), (d, w) -> {
                    float nilai = 0.5f + (bar.getProgress() / 100f);
                    if (untukNada) {
                        act.prefs.setNadaKecepatan(nilai, act.prefs.getKecepatan());
                    } else {
                        act.prefs.setNadaKecepatan(act.prefs.getNada(), nilai);
                    }
                    act.suara.terapkanPengaturan();
                    ucap(untukNada ? "Nada suara disimpan." : "Kecepatan bicara disimpan.");
                    tampilkanMenuMesinSuara();
                })
                .setNegativeButton(L("Kembali"), (d, w) -> tampilkanMenuMesinSuara())
                .setOnCancelListener(d -> tampilkanMenuMesinSuara());
        dialogAktif = tampil(b, untukNada ? "Atur nada bicara, lalu tekan Simpan."
                : "Atur kecepatan bicara, lalu tekan Simpan.");
    }

    private void tampilkanPengaturanNada() {
        tampilkanPengaturanSeekBar(true);
    }

    private void tampilkanPengaturanKecepatan() {
        tampilkanPengaturanSeekBar(false);
    }

    private void tampilkanPengaturanBahasaAplikasi() {
        sedangMenampilkanMenu = true;
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        String[][] pilihan = {
            {"Bahasa Indonesia", "Gunakan Bahasa Indonesia untuk seluruh tampilan dan panduan aplikasi"},
            {"Bahasa Inggris", "Use English for the entire application interface and guidance"},
        };
        for (int i = 0; i < pilihan.length; i++) {
            final int indeks = i + 1;
            TextView baris = buatBaris(L(pilihan[i][0]), L(pilihan[i][1]));
            baris.setOnClickListener(v -> {
                String bahasaDipilih = (indeks == 2) ? "en" : "id";
                act.prefs.setBahasaAplikasi(bahasaDipilih);
                act.prefs.setBahasaSuara(bahasaDipilih);
                act.suara.terapkanPengaturan();
                tutupDialogAktif();
                if ("en".equals(bahasaDipilih)) {
                    ucap("English language selected.");
                } else {
                    ucap("Bahasa Indonesia dipilih.");
                }
                tampilkanMenuPengaturan();
            });
            box.addView(baris);
        }
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L("Pilih Bahasa"))
                .setView(box)
                .setNegativeButton(L("Kembali"), (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    tampilkanMenuPengaturan();
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    tampilkanMenuPengaturan();
                });
        dialogAktif = tampil(b, L("Pilih Bahasa") + ". " + L("Bahasa Indonesia") + " atau " + L("Bahasa Inggris") + ".");
    }

    // ============================================================
    // Pengenalan pertama kali
    // ============================================================

    private static final String TEKS_PENGENALAN =
            "Aplikasi Panduan Kamera Suara ini dikembangkan oleh Ali Bima, Muhammad Ali.\n\n"
            + "CARA PAKAI SINGKAT:\n"
            + "1. Buka aplikasi untuk memunculkan menu.\n"
            + "2. Pilih Ambil Gambar, Rekam Video, atau Pengaturan.\n"
            + "3. Untuk Ambil Gambar atau Rekam Video, pilih kamera belakang atau depan, lalu ikuti panduan suara sampai otomatis memotret atau merekam.\n"
            + "4. Saat sedang merekam video, goncangkan ponsel kapan saja untuk berhenti.\n"
            + "5. Menu Pengaturan dipakai untuk mengatur resolusi foto dan video secara permanen, atau membuka izin Jangan Ganggu, terpisah dari proses pengambilan.\n\n"
            + "AGAR BEKERJA LANCAR, SESUAIKAN DENGAN TIPE HP ANDA:\n"
            + "- Xiaomi, MIUI atau HyperOS: aktifkan izin start otomatis, dan matikan pembatasan baterai untuk aplikasi ini.\n"
            + "- Oppo atau Realme, ColorOS: buka Startup Manager dan pengaturan Baterai, jangan biarkan aplikasi ini dioptimalkan atau dibatasi.\n"
            + "- Vivo, FuntouchOS atau OriginOS: aktifkan Autostart, dan atur pengelolaan daya latar belakang agar tidak membatasi aplikasi ini.\n"
            + "- Semua merek: berikan izin Kamera, Mikrofon, dan Penyimpanan. Untuk fitur Jangan Ganggu saat merekam video, berikan juga izin Akses Kebijakan Notifikasi lewat Pengaturan ponsel.\n"
            + "- Pastikan mesin Text to Speech Bahasa Indonesia sudah terpasang di ponsel Anda.\n\n"
            + "Pesan ini hanya akan muncul sekali saat pertama kali digunakan.";

    void tampilkanPengenalanPertamaKali() {
        sedangMenampilkanMenu = true;
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle("Selamat Datang")
                .setMessage(TEKS_PENGENALAN)
                .setPositiveButton("OK, Mengerti", (d, w) -> {
                    d.dismiss();
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    act.prefs.tandaiKenalan();
                    tampilkanMenuJenis();
                })
                .setOnCancelListener(d -> {
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    act.prefs.tandaiKenalan();
                });
        dialogAktif = tampil(b, TEKS_PENGENALAN);
    }

    // ============================================================
    // Setelah foto/video diambil
    // ============================================================

    void tampilkanMenuSetelahAmbil(final Uri uri, final String mime, final String labelLihat) {
        if (uri == null) return;
        sedangMenampilkanMenu = true;
        String[] opsi = {L(labelLihat), L("Ganti Nama"), L("Bagikan"), L("Hapus"), L("Selesai")};
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(L("Media Tersimpan"))
                .setItems(opsi, (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    if (which == 0) {
                        tampilkanPenampilMedia(uri, mime, labelLihat);
                    } else if (which == 1) {
                        tampilkanDialogGantiNama(uri, mime, labelLihat);
                    } else if (which == 2) {
                        bagikanMedia(uri, mime);
                    } else if (which == 3) {
                        konfirmasiHapus(uri, mime, labelLihat);
                    } else {
                        ucap("Selesai.");
                    }
                })
                .setNegativeButton(L("Selesai"), (d, w) -> tutupMenuDenganPesan(null))
                .setOnCancelListener(d -> tutupMenuDenganPesan(null));
        dialogAktif = tampil(b, "Pilih " + labelLihat + ", Ganti Nama, Bagikan, Hapus, atau Selesai.");
    }

    private void bagikanMedia(Uri uri, String mime) {
        if (uri == null) return;
        try {
            Intent kirim = new Intent(Intent.ACTION_SEND);
            kirim.setType(mime != null ? mime : "*/*");
            kirim.putExtra(Intent.EXTRA_STREAM, uri);
            kirim.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.startActivity(Intent.createChooser(kirim, "Bagikan lewat"));
        } catch (Exception e) {
            ucap("Gagal membuka pilihan aplikasi untuk membagikan.");
        }
    }

    private void konfirmasiHapus(final Uri uri, final String mime, final String labelLihat) {
        if (uri == null) return;
        sedangMenampilkanMenu = true;
        String labelKecil = labelLihat.toLowerCase(Locale.ROOT);
        String[] opsi = {"Ya, hapus", "Batal"};
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle("Hapus berkas ini?")
                .setItems(opsi, (d, which) -> {
                    d.dismiss();
                    dialogAktif = null;
                    sedangMenampilkanMenu = false;
                    if (which == 0) {
                        boolean ok = act.media.hapus(uri);
                        act.getar.nonaktif();
                        ucap(ok ? "Berkas sudah dihapus."
                                : "Gagal menghapus berkas. Coba hapus lewat aplikasi Galeri.");
                    } else {
                        tampilkanMenuSetelahAmbil(uri, mime, labelLihat);
                    }
                })
                .setNegativeButton("Batal", (d, w) -> tampilkanMenuSetelahAmbil(uri, mime, labelLihat))
                .setOnCancelListener(d -> tampilkanMenuSetelahAmbil(uri, mime, labelLihat));
        dialogAktif = tampil(b, "Yakin mau menghapus " + labelKecil
                + "? Tindakan ini tidak bisa dibatalkan. Pilih Ya hapus, atau Batal.");
    }

    private void lanjutKeMenuSetelahRename(final Uri uri, final String mime, final String label, long jedaMs) {
        act.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                tampilkanMenuSetelahAmbil(uri, mime, label);
            }
        }, jedaMs);
    }

    private void tampilkanDialogGantiNama(final Uri uri, final String mime, final String labelLihat) {
        if (uri == null) return;
        final boolean isVideo = mime != null && mime.contains("video/");
        final String ekstensi = isVideo ? ".mp4" : ".jpg";
        String cadangan = (isVideo ? "Video_" : "Foto_") + System.currentTimeMillis() + ekstensi;
        String namaLama = act.media.ambilNama(uri, cadangan);
        String namaAwal = MediaStorage.namaDasarTanpaEkstensi(namaLama, ekstensi);

        LinearLayout layout = new LinearLayout(act);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16), dp(8), dp(16), dp(4));
        final EditText kolomNama = new EditText(act);
        kolomNama.setText(namaAwal);
        kolomNama.setSelectAllOnFocus(true);
        kolomNama.setSingleLine(true);
        kolomNama.setHint(isVideo ? "Nama video" : "Nama foto");
        kolomNama.setContentDescription(isVideo ? "Nama video tanpa ekstensi" : "Nama foto tanpa ekstensi");
        layout.addView(kolomNama, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(isVideo ? "Ganti Nama Video" : "Ganti Nama Foto")
                .setView(layout)
                .setPositiveButton("Simpan Nama", (d, w) -> {
                    String namaBaru = MediaStorage.bersihkanNamaBerkas(kolomNama.getText().toString());
                    if (namaBaru.isEmpty()) {
                        ucap("Nama kosong. Nama lama tetap digunakan.");
                        lanjutKeMenuSetelahRename(uri, mime, labelLihat, 700);
                        return;
                    }
                    namaBaru = MediaStorage.buangEkstensiMedia(namaBaru);
                    if (namaBaru.isEmpty()) {
                        ucap("Nama tidak valid. Nama lama tetap digunakan.");
                        lanjutKeMenuSetelahRename(uri, mime, labelLihat, 700);
                        return;
                    }
                    namaBaru = namaBaru + ekstensi;
                    if (act.media.gantiNama(uri, namaBaru)) {
                        ucap("Nama berhasil diubah menjadi " + namaBaru + ".");
                    } else {
                        ucap("Nama belum berhasil diubah. Nama lama tetap digunakan.");
                    }
                    lanjutKeMenuSetelahRename(uri, mime, labelLihat, 900);
                })
                .setNegativeButton("Lewati", (d, w) -> {
                    ucap("Nama bawaan tetap digunakan.");
                    lanjutKeMenuSetelahRename(uri, mime, labelLihat, 700);
                })
                .setOnCancelListener(d -> lanjutKeMenuSetelahRename(uri, mime, labelLihat, 250));
        dialogAktif = tampil(b, isVideo
                ? "Silakan masukkan nama video. Ekstensi MP4 akan ditambahkan otomatis."
                : "Silakan masukkan nama foto. Ekstensi JPG akan ditambahkan otomatis.");
        try {
            kolomNama.requestFocus();
            kolomNama.selectAll();
        } catch (Exception ignored) {
        }
    }

    // ---------- penampil foto/video ----------

    private Bitmap muatBitmap(Uri uri) {
        try {
            BitmapFactory.Options batas = new BitmapFactory.Options();
            batas.inJustDecodeBounds = true;
            try (InputStream in = act.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, batas);
            }
            int sisiTerbesar = Math.max(batas.outWidth, batas.outHeight);
            int sample = 1;
            while (sisiTerbesar / sample > 2048) sample *= 2;
            BitmapFactory.Options opsi = new BitmapFactory.Options();
            opsi.inSampleSize = sample;
            try (InputStream in = act.getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opsi);
            }
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    private void tampilkanPenampilMedia(final Uri uri, final String mime, final String labelLihat) {
        if (uri == null) return;
        sedangMenampilkanMenu = true;
        tutupDialogAktif();
        final boolean isVideo = mime != null && mime.contains("video/");

        LinearLayout layout = new LinearLayout(act);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16), dp(12), dp(16), dp(12));

        final LinearLayout tombolAksi = new LinearLayout(act);
        tombolAksi.setOrientation(LinearLayout.HORIZONTAL);
        tombolAksi.setGravity(Gravity.CENTER);

        Button tombolBagikan = new Button(act);
        tombolBagikan.setText(L("Bagikan"));
        tombolBagikan.setContentDescription("Bagikan media ini");
        Button tombolKembali = new Button(act);
        tombolKembali.setText(L("Kembali ke menu berbagi"));
        tombolKembali.setContentDescription("Kembali ke menu berbagi");

        final VideoView video = isVideo ? new VideoView(act) : null;
        final ImageView gambar = isVideo ? null : new ImageView(act);
        final Button tombolPutarJeda = isVideo ? new Button(act) : null;

        if (isVideo) {
            video.setVideoURI(uri);
            video.setContentDescription("Video yang baru direkam");
            video.setMinimumHeight(dp(220));
            video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer player) {
                    try {
                        player.setLooping(false);
                    } catch (Exception ignored) {
                    }
                    try {
                        video.start();
                    } catch (Exception ignored) {
                    }
                    tombolPutarJeda.setText("Jeda");
                    tombolPutarJeda.setContentDescription("Jeda video");
                    ucap("Video diputar. Tekan Jeda untuk menjeda, Bagikan untuk membagikan, atau Kembali ke menu berbagi.");
                }
            });
            video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer player) {
                    tombolPutarJeda.setText("Putar lagi");
                    tombolPutarJeda.setContentDescription("Putar video lagi");
                    ucap("Video selesai. Tekan Putar lagi, Bagikan, atau Kembali ke menu berbagi.");
                }
            });
            video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer player, int what, int extra) {
                    ucap("Video tidak dapat diputar. Anda masih dapat membagikannya atau kembali ke menu berbagi.");
                    return true;
                }
            });
            tombolPutarJeda.setText("Putar");
            tombolPutarJeda.setContentDescription("Putar atau jeda video");
            tombolPutarJeda.setOnClickListener(v -> {
                boolean sedangPutar = false;
                try {
                    sedangPutar = video.isPlaying();
                } catch (Exception ignored) {
                }
                if (sedangPutar) {
                    try {
                        video.pause();
                    } catch (Exception ignored) {
                    }
                    tombolPutarJeda.setText("Putar");
                    tombolPutarJeda.setContentDescription("Putar video");
                    ucap("Video dijeda.");
                } else {
                    try {
                        video.start();
                    } catch (Exception ignored) {
                    }
                    tombolPutarJeda.setText("Jeda");
                    tombolPutarJeda.setContentDescription("Jeda video");
                    ucap("Video diputar.");
                }
            });
            layout.addView(video, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            tombolAksi.addView(tombolPutarJeda, new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        } else {
            gambar.setContentDescription("Foto yang baru diambil");
            gambar.setAdjustViewBounds(true);
            gambar.setScaleType(ImageView.ScaleType.FIT_CENTER);
            Bitmap bitmap = muatBitmap(uri);
            if (bitmap != null) {
                gambar.setImageBitmap(bitmap);
                ucap("Foto siap dilihat. Tekan Bagikan untuk membagikan, atau Kembali ke menu berbagi.");
            } else {
                ucap("Foto tidak dapat ditampilkan. Anda masih dapat mencoba membagikannya.");
            }
            layout.addView(gambar, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        }

        tombolBagikan.setOnClickListener(v -> {
            bagikanMedia(uri, mime);
            ucap("Pilih aplikasi untuk membagikan media.");
        });
        tombolKembali.setOnClickListener(v -> {
            if (isVideo) {
                try {
                    video.pause();
                } catch (Exception ignored) {
                }
            }
            AlertDialog d = dialogAktif;
            dialogAktif = null;
            sedangMenampilkanMenu = false;
            if (d != null) {
                try {
                    d.dismiss();
                } catch (Exception ignored) {
                }
            }
            tampilkanMenuSetelahAmbil(uri, mime, labelLihat);
        });
        tombolAksi.addView(tombolBagikan, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        tombolAksi.addView(tombolKembali, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        layout.addView(tombolAksi, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        final Runnable kembaliKeMenu = new Runnable() {
            @Override
            public void run() {
                if (isVideo) {
                    try {
                        video.pause();
                    } catch (Exception ignored) {
                    }
                }
                dialogAktif = null;
                sedangMenampilkanMenu = false;
                tampilkanMenuSetelahAmbil(uri, mime, labelLihat);
            }
        };
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle(isVideo ? "Putar Video" : "Lihat Foto")
                .setView(layout)
                .setNegativeButton(L("Kembali"), (d, w) -> kembaliKeMenu.run())
                .setOnCancelListener(d -> kembaliKeMenu.run());
        dialogAktif = tampil(b, isVideo
                ? "Video dibuka. Anda dapat memutar, menjeda, membagikan, atau kembali ke menu berbagi."
                : "Foto dibuka. Anda dapat membagikan atau kembali ke menu berbagi.");
    }
}
